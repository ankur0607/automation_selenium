package org.ms.com.mock.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.ms.com.mock.bussinessdelegate.OfferExpBussinessDelegateImpl;
import org.ms.com.mock.bussinessdelegate.PSBusinessDelegateImpl;
import org.ms.com.mock.entity.offer.category.CategoryDetails;
import org.ms.com.mock.entity.offer.product.ProductDetails;
import org.ms.com.mock.entity.ps.OfferList;

public class PSControllerTest {

	private PSController psController;

	Map<String, String> requestMap = new HashMap<String, String>();

	@Before
	public void setUp() throws Exception {
		psController = new PSController();
		psController.psBusinessDelegate = new PSBusinessDelegateImpl();
		psController.offerExpBussinessDelegate = new OfferExpBussinessDelegateImpl();
		requestMap.put("coordinates", "72.5596832,23.032966,7000");
		requestMap.put("offset", "0");
		requestMap.put("limit", "20");
		requestMap.put("mastercrdProduct", "MWE");
	}

	@Test
	public void testCategories() {

		CategoryDetails categoryDetails = psController.getOfferCategories();
		assertEquals(6, categoryDetails.getData().size());
	}

	@Test
	public void testProductTypes() {

		ProductDetails productDetails = psController.getOfferProducts();
		assertEquals(46, productDetails.getData().size());
	}

	@Test
	public void test() {

		OfferList offerList = psController.offers(requestMap);
		assertNotEquals(offerList.getData().size(), 0);
	}

	@Test
	public void negativeTestOffer() {
		requestMap.put("coordinates", "");
		OfferList offerList = psController.offers(requestMap);
		assertEquals(null, offerList.getData());
	}

}
