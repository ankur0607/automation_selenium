package org.ms.com.mock.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.ms.com.mock.bussinessdelegate.GoogleBussinessDelegateImpl;
import org.ms.com.mock.entity.google.Google;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
public class GoogleControllerTest {

	private GoogleController googleController;

	Map<String, String> requestMap = new HashMap<String, String>();

	@Before
	public void setUp() throws Exception {
		googleController = new GoogleController();
		googleController.googleBussinessDelegate = new GoogleBussinessDelegateImpl();
		requestMap.put("location", "13.0515491,80.2213267");
		requestMap.put("name", "Pizza hut");
	}

	@Test
	public void test() {

		Google googleObj = googleController.getRating(requestMap);
		assertNotEquals(googleObj.getResults().size(), 0);
	}

	@Test
	public void negativeTest() {
		requestMap.put("location", "");
		Google googleObj = googleController.getRating(requestMap);
		assertEquals(null, googleObj.getResults());
	}

}
