package org.ms.com.mock.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.ms.com.mock.bussinessdelegate.OfferExpBussinessDelegateImpl;
import org.ms.com.mock.entity.ps.OfferList;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
public class OfferExpControllerTest {

	private OfferExpController offerExpController;

	Map<String, String> requestMap = new HashMap<String, String>();

	@Before
	public void setUp() throws Exception {
		offerExpController = new OfferExpController();
		offerExpController.offerExpBussinessDelegate = new OfferExpBussinessDelegateImpl();
		requestMap.put("coordinates", "106.838443,-6.215371,7000");
		requestMap.put("offset", "0");
		requestMap.put("limit", "20");
		requestMap.put("mastercrdProduct", "MWE");
	}

	@Test
	public void testGlobaldata() {

		OfferList offerList = offerExpController.getIndOffers(requestMap);
		assertNotEquals(offerList.getData().size(), 0);
	}
	
	@Test
	public void negtativeTestGlobaldata() {
		requestMap.put("limit","");
		OfferList offerList = offerExpController.getIndOffers(requestMap);
		assertEquals(null, offerList.getData());
	}

}
