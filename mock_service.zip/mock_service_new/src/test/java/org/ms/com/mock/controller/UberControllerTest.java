package org.ms.com.mock.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.ms.com.mock.bussinessdelegate.UberBussinessDelegateImpl;
import org.ms.com.mock.entity.uber.UberPrice;
import org.ms.com.mock.entity.uber.UberTime;

public class UberControllerTest {

	Map<String, String> requestMap = new HashMap<String, String>();
	UberController uberController;

	@Before
	public void setUp() throws Exception {
		uberController = new UberController();
		uberController.uberBussinessDelegate = new UberBussinessDelegateImpl();
		requestMap.put("pickup_lat", "18.550345");
		requestMap.put("pickup_lon", "73.890871");
		requestMap.put("drop_lat", "18.5373570000");
		requestMap.put("drop_lon", "73.8857600000");

	}

	@Test
	public void testUberPrice() {

		UberPrice uberPrice = uberController.getUberPriceEstimate(requestMap);
		assertNotEquals(uberPrice, null);
	}

	@Test
	public void negativeTestUberPrice() {
		requestMap.remove("drop_lat");
		UberPrice uberPrice = uberController.getUberPriceEstimate(requestMap);
		assertEquals(null, uberPrice.getPrices());
	}

	@Test
	public void testUberTime() {
		requestMap.remove("drop_lat");
		requestMap.remove("drop_lon");
		UberTime uberTime = uberController.getUberTimeEstimate(requestMap);
		assertNotEquals(uberTime, null);
	}

	@Test
	public void negativeTestUberTime() {
		requestMap.put("drop_lon", "123");
		UberTime uberTime = uberController.getUberTimeEstimate(requestMap);
		assertEquals(null, uberTime.getTimes());
	}
}
