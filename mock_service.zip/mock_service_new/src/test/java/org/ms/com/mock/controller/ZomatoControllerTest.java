package org.ms.com.mock.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.ms.com.mock.bussinessdelegate.ZomatoBussinessDelegateImpl;
import org.ms.com.mock.entity.zomato.Zomato;

public class ZomatoControllerTest {
private ZomatoController zomatoController;
	
	Map<String,String> requestMap = new HashMap<String,String>();
	
	@Before
	public void setUp() throws Exception {
		zomatoController = new ZomatoController();
		zomatoController.zomatoBussinessDelegate = new ZomatoBussinessDelegateImpl();
		requestMap.put("lat", "18.5124690");
		requestMap.put("lon", "73.9283960");
		requestMap.put("name", "Cafe Coffee Day");
	}

	@Test
	public void test() {
		
		Zomato zomatoObj = zomatoController.getZomatoRatings(requestMap);
		assertNotEquals(zomatoObj.getRestaurants().size(), 0);
	}
	
	@Test
	public void negativeTest() {
		requestMap.put("lat", "18.51246905");
		Zomato zomatoObj = zomatoController.getZomatoRatings(requestMap);
		assertEquals(null, zomatoObj.getRestaurants());
	}

}
