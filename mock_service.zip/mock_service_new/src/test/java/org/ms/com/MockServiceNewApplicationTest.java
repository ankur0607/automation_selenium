package org.ms.com;

import org.junit.Test;

public class MockServiceNewApplicationTest {

	@Test
	public void main() {
		MockServiceNewApplication.main(new String[] {});
	}

}
