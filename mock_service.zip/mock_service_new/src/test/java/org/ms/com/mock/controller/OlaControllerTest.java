package org.ms.com.mock.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.ms.com.mock.bussinessdelegate.OlaBussinessDelegateImpl;
import org.ms.com.mock.entity.ola.Ola;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
public class OlaControllerTest {

private OlaController olaController;
	
	Map<String,String> requestMap = new HashMap<String,String>();
	
	@Before
	public void setUp() throws Exception {
		olaController = new OlaController();
		olaController.olaBussinessDelegate = new OlaBussinessDelegateImpl();
		requestMap.put("pickup_lat", "18.550345");
		requestMap.put("pickup_lon", "73.890871");
		requestMap.put("drop_lat", "18.5373570000");
		requestMap.put("drop_lon", "73.8857600000");
		requestMap.put("pickup_mode", "now");
		requestMap.put("service_type", "p2p");
		
	}

	@Test
	public void test() {	
		Ola olaObj = olaController.rideEstimate(requestMap);
		assertNotEquals(olaObj, null);
	}
	
	@Test
	public void negativeTest() {	
		requestMap.put("pickup_mode","123");
		Ola olaObj = olaController.rideEstimate(requestMap);
		assertEquals(null, olaObj.getRideEstimate());
	}

}
