
package org.ms.com.mock.entity.zomato;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({
    "has_menu_status",
    "res_id"
})
public class R {

    @JsonProperty("has_menu_status")
    private HasMenuStatus hasMenuStatus;
    @JsonProperty("res_id")
    private int resId;

    @JsonProperty("has_menu_status")
    public HasMenuStatus getHasMenuStatus() {
        return hasMenuStatus;
    }

    @JsonProperty("has_menu_status")
    public void setHasMenuStatus(HasMenuStatus hasMenuStatus) {
        this.hasMenuStatus = hasMenuStatus;
    }

    @JsonProperty("res_id")
    public int getResId() {
        return resId;
    }

    @JsonProperty("res_id")
    public void setResId(int resId) {
        this.resId = resId;
    }

}
