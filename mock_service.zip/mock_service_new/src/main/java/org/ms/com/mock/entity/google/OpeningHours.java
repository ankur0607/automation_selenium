
package org.ms.com.mock.entity.google;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({
    "open_now"
})
public class OpeningHours {

    @JsonProperty("open_now")
    private boolean openNow;

    @JsonProperty("open_now")
    public boolean isOpenNow() {
        return openNow;
    }

    @JsonProperty("open_now")
    public void setOpenNow(boolean openNow) {
        this.openNow = openNow;
    }

}
