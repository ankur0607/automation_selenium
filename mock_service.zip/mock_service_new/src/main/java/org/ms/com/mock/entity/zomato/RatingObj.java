
package org.ms.com.mock.entity.zomato;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({
    "title",
    "bg_color"
})
public class RatingObj {

    @JsonProperty("title")
    private Title title;
    @JsonProperty("bg_color")
    private BgColor bgColor;

    @JsonProperty("title")
    public Title getTitle() {
        return title;
    }

    @JsonProperty("title")
    public void setTitle(Title title) {
        this.title = title;
    }

    @JsonProperty("bg_color")
    public BgColor getBgColor() {
        return bgColor;
    }

    @JsonProperty("bg_color")
    public void setBgColor(BgColor bgColor) {
        this.bgColor = bgColor;
    }

}
