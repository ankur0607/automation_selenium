
package org.ms.com.mock.entity.offer.exp;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({
    "rectangleImage ",
    "squareImage"
})
public class OfferImages {

    @JsonProperty("rectangleImage ")
    private String rectangleImage;
    @JsonProperty("squareImage")
    private String squareImage;

    @JsonProperty("rectangleImage ")
    public String getRectangleImage() {
        return rectangleImage;
    }

    @JsonProperty("rectangleImage ")
    public void setRectangleImage(String rectangleImage) {
        this.rectangleImage = rectangleImage;
    }

    @JsonProperty("squareImage")
    public String getSquareImage() {
        return squareImage;
    }

    @JsonProperty("squareImage")
    public void setSquareImage(String squareImage) {
        this.squareImage = squareImage;
    }

}
