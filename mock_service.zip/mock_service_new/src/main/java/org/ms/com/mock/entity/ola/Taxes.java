
package org.ms.com.mock.entity.ola;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


@JsonPropertyOrder({
    "total_tax"
})
public class Taxes {

    @JsonProperty("total_tax")
    private double totalTax;

    @JsonProperty("total_tax")
    public double getTotalTax() {
        return totalTax;
    }

    @JsonProperty("total_tax")
    public void setTotalTax(double totalTax) {
        this.totalTax = totalTax;
    }

}
