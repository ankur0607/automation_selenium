package org.ms.com.mock.bussinessdelegate;

import java.io.InputStream;
import java.util.Map;

import org.ms.com.mock.common.FileUtil;
import org.ms.com.mock.constant.MockConstants;
import org.ms.com.mock.entity.uber.UberPrice;
import org.ms.com.mock.entity.uber.UberTime;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class UberBussinessDelegateImpl implements UberBussinessDelegate {
	/**
	 *
	 * In this method file name should be /ola_Parameters.json
	 * 
	 * Sequence :- end_latitude --> end_longitude-->start_longitude
	 * -->start_longitude Ascending order of keys. Every parameter should be
	 * separated by _ Spaces in name should be replaced by _ and file name should be
	 * in small letters
	 *
	 */

	@Override
	public UberPrice getUberPriceEstimate(Map<String, String> uberCriteria) {
		String filepathPrice = MockConstants.SLASH +MockConstants.UBER_FILE_PATH;
		UberPrice uberPrice = new UberPrice();
		filepathPrice = FileUtil.getFilepath(filepathPrice, uberCriteria);
		try {
			if (filepathPrice != null) {
				ObjectMapper objectMapper = new ObjectMapper();
				objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
				InputStream is = null;
				log.info("filename :-" + filepathPrice);
				is = OlaBussinessDelegateImpl.class.getResourceAsStream(filepathPrice);
				if (is != null) {
					uberPrice = objectMapper.readValue(is, UberPrice.class);
					log.info("Uber record fetched for price estimation");
				} else {
					log.info("Incorrect information, Please provide correct information");
				}

			}
		} catch (Exception e) {

			log.info("Static file read for Uber Price : " + e.getMessage());
		}
		return uberPrice;
	}

	/**
	 *
	 * In this method file name should be /ola_Parameters.json
	 * 
	 * Sequence :- start_latitude -->start_longitude Ascending order of keys. Every
	 * parameter should be separated by _ Spaces in name should be replaced by _ and
	 * file name should be in small letters
	 *
	 */
	@Override
	public UberTime getUberTimeEstimate(Map<String, String> uberCriteria) {
		String filepathTime = MockConstants.SLASH + MockConstants.UBER_FILE_PATH;
		UberTime uberTime = new UberTime();
		filepathTime = FileUtil.getFilepath(filepathTime, uberCriteria);
		try {
			if (filepathTime != null) {
				ObjectMapper objectMapper = new ObjectMapper();
				objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
				InputStream is = null;
				log.info("filename :-" + filepathTime);
				is = OlaBussinessDelegateImpl.class.getResourceAsStream(filepathTime);
				if (is != null) {
					uberTime = objectMapper.readValue(is, UberTime.class);
					log.info("Uber record fetched for time estimation :- ");
				} else {
					log.info("Incorrect information, Please provide correct information");
				}

			}
		} catch (Exception e) {

			log.info("Static file read for Uber Time : " + e.getMessage());
		}
		return uberTime;
	}

}
