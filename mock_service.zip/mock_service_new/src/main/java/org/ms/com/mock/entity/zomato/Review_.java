
package org.ms.com.mock.entity.zomato;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({
    "rating",
    "review_text",
    "id",
    "rating_color",
    "review_time_friendly",
    "rating_text",
    "timestamp",
    "likes",
    "user",
    "comments_count"
})
public class Review_ {

    @JsonProperty("rating")
    private int rating;
    @JsonProperty("review_text")
    private String reviewText;
    @JsonProperty("id")
    private int id;
    @JsonProperty("rating_color")
    private String ratingColor;
    @JsonProperty("review_time_friendly")
    private String reviewTimeFriendly;
    @JsonProperty("rating_text")
    private String ratingText;
    @JsonProperty("timestamp")
    private int timestamp;
    @JsonProperty("likes")
    private int likes;
    @JsonProperty("user")
    private User_ user;
    @JsonProperty("comments_count")
    private int commentsCount;

    @JsonProperty("rating")
    public int getRating() {
        return rating;
    }

    @JsonProperty("rating")
    public void setRating(int rating) {
        this.rating = rating;
    }

    @JsonProperty("review_text")
    public String getReviewText() {
        return reviewText;
    }

    @JsonProperty("review_text")
    public void setReviewText(String reviewText) {
        this.reviewText = reviewText;
    }

    @JsonProperty("id")
    public int getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(int id) {
        this.id = id;
    }

    @JsonProperty("rating_color")
    public String getRatingColor() {
        return ratingColor;
    }

    @JsonProperty("rating_color")
    public void setRatingColor(String ratingColor) {
        this.ratingColor = ratingColor;
    }

    @JsonProperty("review_time_friendly")
    public String getReviewTimeFriendly() {
        return reviewTimeFriendly;
    }

    @JsonProperty("review_time_friendly")
    public void setReviewTimeFriendly(String reviewTimeFriendly) {
        this.reviewTimeFriendly = reviewTimeFriendly;
    }

    @JsonProperty("rating_text")
    public String getRatingText() {
        return ratingText;
    }

    @JsonProperty("rating_text")
    public void setRatingText(String ratingText) {
        this.ratingText = ratingText;
    }

    @JsonProperty("timestamp")
    public int getTimestamp() {
        return timestamp;
    }

    @JsonProperty("timestamp")
    public void setTimestamp(int timestamp) {
        this.timestamp = timestamp;
    }

    @JsonProperty("likes")
    public int getLikes() {
        return likes;
    }

    @JsonProperty("likes")
    public void setLikes(int likes) {
        this.likes = likes;
    }

    @JsonProperty("user")
    public User_ getUser() {
        return user;
    }

    @JsonProperty("user")
    public void setUser(User_ user) {
        this.user = user;
    }

    @JsonProperty("comments_count")
    public int getCommentsCount() {
        return commentsCount;
    }

    @JsonProperty("comments_count")
    public void setCommentsCount(int commentsCount) {
        this.commentsCount = commentsCount;
    }

}
