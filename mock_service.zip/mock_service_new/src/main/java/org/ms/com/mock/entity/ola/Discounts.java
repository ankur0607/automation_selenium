
package org.ms.com.mock.entity.ola;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


@JsonPropertyOrder({
    "discount_type",
    "discount_code",
    "discount_mode",
    "discount",
    "cashback",
    "pass_savings"
})
public class Discounts {

    @JsonProperty("discount_type")
    private String discountType;
    @JsonProperty("discount_code")
    private String discountCode;
    @JsonProperty("discount_mode")
    private String discountMode;
    @JsonProperty("discount")
    private int discount;
    @JsonProperty("cashback")
    private int cashback;
    @JsonProperty("pass_savings")
    private int passSavings;

    @JsonProperty("discount_type")
    public String getDiscountType() {
        return discountType;
    }

    @JsonProperty("discount_type")
    public void setDiscountType(String discountType) {
        this.discountType = discountType;
    }

    @JsonProperty("discount_code")
    public String getDiscountCode() {
        return discountCode;
    }

    @JsonProperty("discount_code")
    public void setDiscountCode(String discountCode) {
        this.discountCode = discountCode;
    }

    @JsonProperty("discount_mode")
    public String getDiscountMode() {
        return discountMode;
    }

    @JsonProperty("discount_mode")
    public void setDiscountMode(String discountMode) {
        this.discountMode = discountMode;
    }

    @JsonProperty("discount")
    public int getDiscount() {
        return discount;
    }

    @JsonProperty("discount")
    public void setDiscount(int discount) {
        this.discount = discount;
    }

    @JsonProperty("cashback")
    public int getCashback() {
        return cashback;
    }

    @JsonProperty("cashback")
    public void setCashback(int cashback) {
        this.cashback = cashback;
    }

    @JsonProperty("pass_savings")
    public int getPassSavings() {
        return passSavings;
    }

    @JsonProperty("pass_savings")
    public void setPassSavings(int passSavings) {
        this.passSavings = passSavings;
    }

}
