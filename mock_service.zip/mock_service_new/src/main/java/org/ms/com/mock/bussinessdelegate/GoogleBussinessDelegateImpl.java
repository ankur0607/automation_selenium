package org.ms.com.mock.bussinessdelegate;

import java.io.InputStream;
import java.util.Map;

import org.ms.com.mock.common.FileUtil;
import org.ms.com.mock.constant.MockConstants;
import org.ms.com.mock.entity.google.Google;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class GoogleBussinessDelegateImpl implements GoogleBussinessDelegate {

	/**
	 *
	 * In this method file name should be /google_Parameters.json
	 * 
	 * Sequence :- location -->name Every parameter should be separated by _ Spaces
	 * in name should be replaced by _ and file name should be in small letters
	 *
	 */
	@Override
	public Google nearBy(Map<String, String> googleCriteria) {

		Google googleData = new Google();
		String filepath = MockConstants.SLASH + MockConstants.GOOGLE_FILE_PATH;
		filepath = FileUtil.getFilepath(filepath, googleCriteria);
		try {
			if (filepath != null) {
				ObjectMapper objectMapper = new ObjectMapper();
				objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
				InputStream is = null;
				log.info("filename:    " + filepath);
				is = GoogleBussinessDelegateImpl.class.getResourceAsStream(filepath);
				if (is != null) {

					googleData = objectMapper.readValue(is, Google.class);
					log.info("Number of google records fetched : " + googleData.getResults().size());
				} else {
					log.info("Information is not correct, Please provide correct information to fetch data. Location:");
				}
			}
		} catch (Exception e) {

			log.info("Static file read : " + e.getMessage());
		}

		return googleData;
	}

}
