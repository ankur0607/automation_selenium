package org.ms.com.mock.controller;

import java.util.Map;

import org.ms.com.mock.bussinessdelegate.ZomatoBussinessDelegate;
import org.ms.com.mock.entity.zomato.Zomato;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ZomatoController {

	@Autowired
	ZomatoBussinessDelegate zomatoBussinessDelegate;

	@GetMapping(value = "/zomato")
	public Zomato getZomatoRatings(@RequestParam Map<String, String> requestParam) {
		return zomatoBussinessDelegate.getRestaurants(requestParam);
	}

}
