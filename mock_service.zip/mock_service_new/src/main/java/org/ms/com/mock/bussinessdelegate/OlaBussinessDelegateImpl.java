package org.ms.com.mock.bussinessdelegate;

import java.io.InputStream;
import java.util.Map;

import org.ms.com.mock.common.FileUtil;
import org.ms.com.mock.constant.MockConstants;
import org.ms.com.mock.entity.ola.Ola;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class OlaBussinessDelegateImpl implements OlaBussinessDelegate {

	/**
	 *
	 * In this method file name should be /ola_Parameters.json
	 * 
	 * Sequence :- drop_lat --> drop_lng -->pickup_lat --> pickup_lng -->pickup_mode
	 * -->service_type Ascending order of keys. Every parameter should be separated
	 * by _ Spaces in name should be replaced by _ and file name should be in small
	 * letters
	 *
	 */
	@Override
	public Ola getRideEstimation(Map<String, String> olaCriteria) {
		Ola ola = new Ola();
		String filepath = MockConstants.SLASH + MockConstants.OLA_FILE_PATH;

		filepath = FileUtil.getFilepath(filepath, olaCriteria);
		try {
			if (filepath != null) {
				ObjectMapper objectMapper = new ObjectMapper();
				objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
				InputStream is = null;
				log.info("filename :-" + filepath);
				is = OlaBussinessDelegateImpl.class.getResourceAsStream(filepath);
				if (is != null) {
					ola = objectMapper.readValue(is, Ola.class);
					log.info("Number of ola records fetched");
				} else {
					log.info("Incorrect information, Please provide correct information");
				}

			}
		} catch (Exception e) {

			log.info("Static file read : " + e.getMessage());
		}
		return ola;
	}

}
