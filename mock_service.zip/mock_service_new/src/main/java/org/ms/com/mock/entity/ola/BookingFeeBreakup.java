
package org.ms.com.mock.entity.ola;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


@JsonPropertyOrder({
    "display_text",
    "value"
})
public class BookingFeeBreakup {

    @JsonProperty("display_text")
    private String displayText;
    @JsonProperty("value")
    private int value;

    @JsonProperty("display_text")
    public String getDisplayText() {
        return displayText;
    }

    @JsonProperty("display_text")
    public void setDisplayText(String displayText) {
        this.displayText = displayText;
    }

    @JsonProperty("value")
    public int getValue() {
        return value;
    }

    @JsonProperty("value")
    public void setValue(int value) {
        this.value = value;
    }

}
