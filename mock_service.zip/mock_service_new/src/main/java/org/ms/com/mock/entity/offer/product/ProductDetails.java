
package org.ms.com.mock.entity.offer.product;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({
    "count",
    "data"
})
public class ProductDetails {

    @JsonProperty("count")
    private int count;
    @JsonProperty("data")
    private List<Product> data = null;

    @JsonProperty("count")
    public int getCount() {
        return count;
    }

    @JsonProperty("count")
    public void setCount(int count) {
        this.count = count;
    }

    @JsonProperty("data")
    public List<Product> getData() {
        return data;
    }

    @JsonProperty("data")
    public void setData(List<Product> data) {
        this.data = data;
    }

}
