
package org.ms.com.mock.entity.zomato;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


@JsonPropertyOrder({
    "type",
    "tint"
})
public class BgColor {

    @JsonProperty("type")
    private String type;
    @JsonProperty("tint")
    private String tint;

    @JsonProperty("type")
    public String getType() {
        return type;
    }

    @JsonProperty("type")
    public void setType(String type) {
        this.type = type;
    }

    @JsonProperty("tint")
    public String getTint() {
        return tint;
    }

    @JsonProperty("tint")
    public void setTint(String tint) {
        this.tint = tint;
    }

}
