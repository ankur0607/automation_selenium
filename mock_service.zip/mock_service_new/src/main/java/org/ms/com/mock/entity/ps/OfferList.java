
package org.ms.com.mock.entity.ps;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


public class OfferList {

   
    private int count;
   
    private List<Offer> data = null;

   
    public int getCount() {
        return count;
    }

   
    public void setCount(int count) {
        this.count = count;
    }

   
    public List<Offer> getData() {
        return data;
    }

   
    public void setData(List<Offer> data) {
        this.data = data;
    }

}
