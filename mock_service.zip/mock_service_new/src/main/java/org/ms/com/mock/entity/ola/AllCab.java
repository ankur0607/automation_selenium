
package org.ms.com.mock.entity.ola;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


@JsonPropertyOrder({
    "lat",
    "lng",
    "id",
    "bearing",
    "accuracy"
})
public class AllCab {

    @JsonProperty("lat")
    private double lat;
    @JsonProperty("lng")
    private double lng;
    @JsonProperty("id")
    private String id;
    @JsonProperty("bearing")
    private int bearing;
    @JsonProperty("accuracy")
    private int accuracy;

    @JsonProperty("lat")
    public double getLat() {
        return lat;
    }

    @JsonProperty("lat")
    public void setLat(double lat) {
        this.lat = lat;
    }

    @JsonProperty("lng")
    public double getLng() {
        return lng;
    }

    @JsonProperty("lng")
    public void setLng(double lng) {
        this.lng = lng;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    @JsonProperty("bearing")
    public int getBearing() {
        return bearing;
    }

    @JsonProperty("bearing")
    public void setBearing(int bearing) {
        this.bearing = bearing;
    }

    @JsonProperty("accuracy")
    public int getAccuracy() {
        return accuracy;
    }

    @JsonProperty("accuracy")
    public void setAccuracy(int accuracy) {
        this.accuracy = accuracy;
    }

}
