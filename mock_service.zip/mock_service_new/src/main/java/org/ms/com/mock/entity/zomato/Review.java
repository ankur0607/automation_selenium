
package org.ms.com.mock.entity.zomato;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({
    "review"
})
public class Review {

    @JsonProperty("review")
    private Review_ review;

    @JsonProperty("review")
    public Review_ getReview() {
        return review;
    }

    @JsonProperty("review")
    public void setReview(Review_ review) {
        this.review = review;
    }

}
