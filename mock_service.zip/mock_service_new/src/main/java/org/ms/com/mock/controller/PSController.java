package org.ms.com.mock.controller;

import java.util.Map;

import org.ms.com.mock.bussinessdelegate.OfferExpBussinessDelegate;
import org.ms.com.mock.bussinessdelegate.PSBusinessDelegate;
import org.ms.com.mock.entity.offer.category.CategoryDetails;
import org.ms.com.mock.entity.offer.product.ProductDetails;
import org.ms.com.mock.entity.ps.OfferList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author kkumari6358
 * 
 */
@RestController
public class PSController {

	@Autowired
	PSBusinessDelegate psBusinessDelegate;

	@Autowired
	OfferExpBussinessDelegate offerExpBussinessDelegate;

	@GetMapping(value = "/offers")
	public OfferList offers(@RequestParam Map<String, String> requestParam) {
		return psBusinessDelegate.getOffers(requestParam);
	}

	@GetMapping(value = "/categories")
	public CategoryDetails getOfferCategories() {
		return offerExpBussinessDelegate.getExpOfferCategories();
	}

	@GetMapping(value = "/mastercard-products")
	public ProductDetails getOfferProducts() {
		return offerExpBussinessDelegate.getExpOfferProducts();
	}

}
