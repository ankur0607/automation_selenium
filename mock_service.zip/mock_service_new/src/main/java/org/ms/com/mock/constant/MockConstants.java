package org.ms.com.mock.constant;

public class MockConstants {
	
	private MockConstants() {
		throw new IllegalStateException("Utility Class, Object cannot be created");
	}

	public static final String CATEGORY_TYPE_PATH = "offers_exp/offer_exp_categories.json";
	public static final String PRODUCT_TYPE_PATH = "offers_exp/offer_exp_products.json";
	public static final String IND_FILE_PATH = "locale/ind";
	public static final String GOOGLE_FILE_PATH = "google/google";
	public static final String OLA_FILE_PATH = "ola/ola";
	public static final String PS_FILE_PATH = "ps/ps";
	public static final String UBER_FILE_PATH = "uber/uber";
	public static final String ZOMATO_FILE_PATH = "zomato/zomato";
	public static final String SLASH = "/";
}
