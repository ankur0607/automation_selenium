package org.ms.com.mock.bussinessdelegate;

import java.util.Map;

import org.ms.com.mock.entity.ps.OfferList;



/**
 * @author kkumari6358
 *
 */
public interface PSBusinessDelegate {
	
	public OfferList getOffers(Map<String, String> offerCriteria);
	
}
