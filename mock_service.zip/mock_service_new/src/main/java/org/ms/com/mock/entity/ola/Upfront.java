
package org.ms.com.mock.entity.ola;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({
    "fare",
    "fare_id",
    "is_upfront_applicable"
})
public class Upfront {

    @JsonProperty("fare")
    private int fare;
    @JsonProperty("fare_id")
    private String fareId;
    @JsonProperty("is_upfront_applicable")
    private boolean isUpfrontApplicable;

    @JsonProperty("fare")
    public int getFare() {
        return fare;
    }

    @JsonProperty("fare")
    public void setFare(int fare) {
        this.fare = fare;
    }

    @JsonProperty("fare_id")
    public String getFareId() {
        return fareId;
    }

    @JsonProperty("fare_id")
    public void setFareId(String fareId) {
        this.fareId = fareId;
    }

    @JsonProperty("is_upfront_applicable")
    public boolean isIsUpfrontApplicable() {
        return isUpfrontApplicable;
    }

    @JsonProperty("is_upfront_applicable")
    public void setIsUpfrontApplicable(boolean isUpfrontApplicable) {
        this.isUpfrontApplicable = isUpfrontApplicable;
    }

}
