package org.ms.com.mock.controller;

import java.util.Map;

import org.ms.com.mock.bussinessdelegate.GoogleBussinessDelegate;
import org.ms.com.mock.entity.google.Google;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class GoogleController {

	@Autowired
	GoogleBussinessDelegate googleBussinessDelegate;

	@GetMapping(value = "/google")
	public Google getRating(@RequestParam Map<String, String> requestParam) {

		return googleBussinessDelegate.nearBy(requestParam);
	}

}
