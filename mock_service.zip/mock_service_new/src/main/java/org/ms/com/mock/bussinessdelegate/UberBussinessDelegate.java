package org.ms.com.mock.bussinessdelegate;

import java.util.Map;

import org.ms.com.mock.entity.uber.UberPrice;
import org.ms.com.mock.entity.uber.UberTime;

public interface UberBussinessDelegate {
	
	public UberPrice getUberPriceEstimate( Map<String, String> uberCriteria);
	public UberTime getUberTimeEstimate( Map<String, String> uberCriteria);

}
