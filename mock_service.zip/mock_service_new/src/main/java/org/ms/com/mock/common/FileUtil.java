package org.ms.com.mock.common;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Collectors;

public class FileUtil {

	private FileUtil() {
		throw new IllegalStateException("Utility Class, Object cannot be created");
	}

	public static String getFilepath(String filepath, Map<String, String> criteria) {
		StringBuilder filename = new StringBuilder(filepath);
		if (criteria != null) {
			Map<String, String> sortedCriteria = criteria.entrySet().stream().sorted(Map.Entry.comparingByKey())
					.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (oldValue, newValue) -> oldValue,
							LinkedHashMap::new));

			for (Map.Entry<String, String> criteriaEntry : sortedCriteria.entrySet()) {
				String value = criteriaEntry.getValue();
				String key = criteriaEntry.getKey();
				if (value.contains(",") && value.split(",").length != 3 && filepath.contains("ps")) {
					value += ",500";
				}
				if (!key.equalsIgnoreCase("key") && !(filepath.contains("google") && key.contains("radius")) ) {
					filename.append("_").append(value.trim().replaceAll(" ", "_").toLowerCase());
				}

			}
		}
		filename.append(".json");
		return filename.toString();
	}
}
