package org.ms.com.mock.entity.ps;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

//@Document(collection= "PS")
public class Offer {
	
	
	private String language;
	
	private OfferDetails offerDetails;
	
	private List<String> eligibleMastercardProducts = null;
	
	private List<String> eligibleMarkets = null;
	
	private List<String> destinationMarkets;
	
	private MerchantDetails merchantDetails;
	
	private OfferImages offerImages;
	
	@JsonIgnore
	private Location  location;
	
	
	public Location getLocation() {
		return location;
	}

	public void setLocation(Location location) {
		this.location = location;
	}

	public String getLanguage() {
	return language;
	}

	public OfferDetails getOfferDetails() {
	return offerDetails;
	}

	public List<String> getEligibleMastercardProducts() {
	return eligibleMastercardProducts;
	}

	public List<String> getEligibleMarkets() {
	return eligibleMarkets;
	}
	
	public List<String> getDestinationMarkets() {
	return destinationMarkets;
	}

	public MerchantDetails getMerchantDetails() {
	return merchantDetails;
	}
	
	public void setMerchantDetails(MerchantDetails merchantDetails) {
	this.merchantDetails = merchantDetails;
	}

	public OfferImages getOfferImages() {
	return offerImages;
	}
	
	}
	
	class OfferImages {

	
	private String rectangleImage;
	
	private String squareImage;

	
	public String getRectangleImage() {
	return rectangleImage;
	}

	
	public void setRectangleImage(String rectangleImage) {
	this.rectangleImage = rectangleImage;
	}

	
	public String getSquareImage() {
	return squareImage;
	}

	
	public void setSquareImage(String squareImage) {
	this.squareImage = squareImage;
	}


	}



