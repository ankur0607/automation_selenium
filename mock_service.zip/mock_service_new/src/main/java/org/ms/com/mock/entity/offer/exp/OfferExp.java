package org.ms.com.mock.entity.offer.exp;

import java.util.List;

public class OfferExp {

	private List<Offer> offers = null;

	public List<Offer> getOffers() {
		return offers;
	}

	public void setOffers(List<Offer> offers) {
		this.offers = offers;
	}
}
