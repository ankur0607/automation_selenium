package org.ms.com.mock.bussinessdelegate;

import java.util.Map;

import org.ms.com.mock.entity.ola.Ola;

public interface OlaBussinessDelegate {
	
	public Ola getRideEstimation(Map<String,String> requestParam);

}
