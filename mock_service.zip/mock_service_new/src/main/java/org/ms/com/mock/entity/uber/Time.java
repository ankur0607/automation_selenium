
package org.ms.com.mock.entity.uber;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "localized_display_name",
    "estimate",
    "display_name",
    "product_id"
})
public class Time {

    @JsonProperty("localized_display_name")
    private String localizedDisplayName;
    @JsonProperty("estimate")
    private int estimate;
    @JsonProperty("display_name")
    private String displayName;
    @JsonProperty("product_id")
    private String productId;

    @JsonProperty("localized_display_name")
    public String getLocalizedDisplayName() {
        return localizedDisplayName;
    }

    @JsonProperty("localized_display_name")
    public void setLocalizedDisplayName(String localizedDisplayName) {
        this.localizedDisplayName = localizedDisplayName;
    }

    @JsonProperty("estimate")
    public int getEstimate() {
        return estimate;
    }

    @JsonProperty("estimate")
    public void setEstimate(int estimate) {
        this.estimate = estimate;
    }

    @JsonProperty("display_name")
    public String getDisplayName() {
        return displayName;
    }

    @JsonProperty("display_name")
    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    @JsonProperty("product_id")
    public String getProductId() {
        return productId;
    }

    @JsonProperty("product_id")
    public void setProductId(String productId) {
        this.productId = productId;
    }

}
