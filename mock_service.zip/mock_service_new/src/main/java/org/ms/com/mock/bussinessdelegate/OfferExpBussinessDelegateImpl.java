package org.ms.com.mock.bussinessdelegate;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Map;

import org.ms.com.mock.common.FileUtil;
import org.ms.com.mock.constant.MockConstants;
import org.ms.com.mock.entity.offer.category.CategoryDetails;
import org.ms.com.mock.entity.offer.product.ProductDetails;
import org.ms.com.mock.entity.ps.OfferList;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class OfferExpBussinessDelegateImpl implements OfferExpBussinessDelegate {
	
	public CategoryDetails getExpOfferCategories() {
		CategoryDetails categoryDetails = new CategoryDetails();
		String filepath = MockConstants.SLASH + MockConstants.CATEGORY_TYPE_PATH;
		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
		InputStream is = OfferExpBussinessDelegateImpl.class.getResourceAsStream(filepath);

		try {
			categoryDetails = objectMapper.readValue(is, CategoryDetails.class);
		} catch (IOException e) {
			log.info("Static file read for categories: " + e.getMessage());
		}

		return categoryDetails;
	}

	public ProductDetails getExpOfferProducts() {
		ProductDetails productDetails = new ProductDetails();
		String filepath = MockConstants.SLASH + MockConstants.PRODUCT_TYPE_PATH;
		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
		InputStream is = OfferExpBussinessDelegateImpl.class.getResourceAsStream(filepath);

		try {
			productDetails = objectMapper.readValue(is, ProductDetails.class);
		} catch (IOException e) {
			log.info("Static file read for product types : " + e.getMessage());
		}

		return productDetails;
	}

	@Override
	public OfferList getIndOffers(Map<String, String> requestParam) {

		OfferList offerExp = new OfferList();
		Gson gson = new Gson();
		String filepath = MockConstants.SLASH + MockConstants.IND_FILE_PATH;
		filepath = FileUtil.getFilepath(filepath, requestParam);
		try {
			if (filepath != null) {
				InputStream is = null;
				log.info("filename:    " + filepath);
				is = OfferExpBussinessDelegateImpl.class.getResourceAsStream(filepath);
				if (is != null) {
					final BufferedReader in = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
					offerExp = gson.fromJson(in, new TypeToken<OfferList>() {
					}.getType());
					log.info("Offer experience records fetched for Indonesia");
				} else {
					log.info("Information is not correct, Please provide correct information to fetch data.");
				}
			}
		} catch (Exception e) {

			log.info("Static file read for global: " + e.getMessage());
		}
		return offerExp;
	}

}
