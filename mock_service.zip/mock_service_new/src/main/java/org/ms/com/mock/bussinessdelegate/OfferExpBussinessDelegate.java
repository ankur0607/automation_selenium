package org.ms.com.mock.bussinessdelegate;

import java.util.Map;

import org.ms.com.mock.entity.offer.category.CategoryDetails;
import org.ms.com.mock.entity.offer.product.ProductDetails;
import org.ms.com.mock.entity.ps.OfferList;

public interface OfferExpBussinessDelegate {
	public CategoryDetails getExpOfferCategories();
	public ProductDetails getExpOfferProducts();
	public OfferList getIndOffers(Map<String, String> requestParam);
}
