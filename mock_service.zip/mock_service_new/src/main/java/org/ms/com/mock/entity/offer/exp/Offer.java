
package org.ms.com.mock.entity.offer.exp;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


@JsonPropertyOrder({
    "offerId ",
    "title ",
    "subTitle ",
    "description ",
    "category ",
    "distanceToMerchant ",
    "distanceUnit",
    "eligibility",
    "offerImages ",
    "merchant"
})
public class Offer {

    @JsonProperty("offerId ")
    private String offerId;
    @JsonProperty("title ")
    private String title;
    @JsonProperty("subTitle ")
    private String subTitle;
    @JsonProperty("description ")
    private String description;
    @JsonProperty("category ")
    private String category;
    @JsonProperty("distanceToMerchant ")
    private double distanceToMerchant;
    @JsonProperty("distanceUnit")
    private String distanceUnit;
    @JsonProperty("eligibility")
    private Eligibility eligibility;
    @JsonProperty("offerImages ")
    private OfferImages offerImages;
    @JsonProperty("merchant")
    private Merchant merchant;

    @JsonProperty("offerId ")
    public String getOfferId() {
        return offerId;
    }

    @JsonProperty("offerId ")
    public void setOfferId(String offerId) {
        this.offerId = offerId;
    }

    @JsonProperty("title ")
    public String getTitle() {
        return title;
    }

    @JsonProperty("title ")
    public void setTitle(String title) {
        this.title = title;
    }

    @JsonProperty("subTitle ")
    public String getSubTitle() {
        return subTitle;
    }

    @JsonProperty("subTitle ")
    public void setSubTitle(String subTitle) {
        this.subTitle = subTitle;
    }

    @JsonProperty("description ")
    public String getDescription() {
        return description;
    }

    @JsonProperty("description ")
    public void setDescription(String description) {
        this.description = description;
    }

    @JsonProperty("category ")
    public String getCategory() {
        return category;
    }

    @JsonProperty("category ")
    public void setCategory(String category) {
        this.category = category;
    }

    @JsonProperty("distanceToMerchant ")
    public double getDistanceToMerchant() {
        return distanceToMerchant;
    }

    @JsonProperty("distanceToMerchant ")
    public void setDistanceToMerchant(double distanceToMerchant) {
        this.distanceToMerchant = distanceToMerchant;
    }

    @JsonProperty("distanceUnit")
    public String getDistanceUnit() {
        return distanceUnit;
    }

    @JsonProperty("distanceUnit")
    public void setDistanceUnit(String distanceUnit) {
        this.distanceUnit = distanceUnit;
    }

    @JsonProperty("eligibility")
    public Eligibility getEligibility() {
        return eligibility;
    }

    @JsonProperty("eligibility")
    public void setEligibility(Eligibility eligibility) {
        this.eligibility = eligibility;
    }

    @JsonProperty("offerImages ")
    public OfferImages getOfferImages() {
        return offerImages;
    }

    @JsonProperty("offerImages ")
    public void setOfferImages(OfferImages offerImages) {
        this.offerImages = offerImages;
    }

    @JsonProperty("merchant")
    public Merchant getMerchant() {
        return merchant;
    }

    @JsonProperty("merchant")
    public void setMerchant(Merchant merchant) {
        this.merchant = merchant;
    }

}
