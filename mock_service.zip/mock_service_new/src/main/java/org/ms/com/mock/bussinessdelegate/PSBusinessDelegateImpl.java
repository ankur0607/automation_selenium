package org.ms.com.mock.bussinessdelegate;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Map;

import org.ms.com.mock.common.FileUtil;
import org.ms.com.mock.constant.MockConstants;
import org.ms.com.mock.entity.ps.OfferList;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import lombok.extern.slf4j.Slf4j;

/**
 * @author kkumari6358
 *
 */

@Service
@Slf4j
public class PSBusinessDelegateImpl implements PSBusinessDelegate {
	/**
	 *
	 * In this method file name should be /ps_Parameters.json
	 * 
	 * Sequence :- coordinates -->limit-->mastercardProduct
	 * -->merchantName/offerTitle --> offset Every parameter should be separated by
	 * _ Spaces in name should be replaced by _ and file name should be in small
	 * letters
	 *
	 */
	@Override
	public OfferList getOffers(Map<String, String> offerCriteria) {

		OfferList offerList = new OfferList();
		InputStream is = null;
		String filepath = MockConstants.SLASH + MockConstants.PS_FILE_PATH;
		filepath = FileUtil.getFilepath(filepath, offerCriteria);
		Gson gson = new Gson();
		log.info("filename :-" + filepath);
		if (filepath != null) {

			is = PSBusinessDelegateImpl.class.getResourceAsStream(filepath);
		}

		if (is != null) {
			final BufferedReader in = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
			offerList = gson.fromJson(in, new TypeToken<OfferList>() {
			}.getType());
			offerList.setCount(offerList.getData().size());
		} else {
			log.info("Incorrect imformation provided.");
		}
		return offerList;
	}

}
