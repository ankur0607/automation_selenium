package org.ms.com.mock.bussinessdelegate;

import java.io.InputStream;
import java.util.Map;

import org.ms.com.mock.common.FileUtil;
import org.ms.com.mock.constant.MockConstants;
import org.ms.com.mock.entity.zomato.Zomato;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ZomatoBussinessDelegateImpl implements ZomatoBussinessDelegate {

	/**
	 *
	 * In this method file name should be /zomato_Parameters.json
	 * 
	 * Sequence :- latitude -->longitude -->name Every parameter should be separated
	 * by _ Spaces in name should be replaced by _ and file name should be in small
	 * letters
	 *
	 */
	@Override
	public Zomato getRestaurants(Map<String, String> zomatoCriteria) {

		Zomato zomatoList = new Zomato();
		String filepath = MockConstants.SLASH + MockConstants.ZOMATO_FILE_PATH;
		filepath = FileUtil.getFilepath(filepath, zomatoCriteria);
		try {
			if (filepath != null) {
				ObjectMapper objectMapper = new ObjectMapper();
				objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
				InputStream is = ZomatoBussinessDelegateImpl.class.getResourceAsStream(filepath);
				log.info("filename :" + filepath);
				if (is != null) {
					zomatoList = objectMapper.readValue(is, Zomato.class);
					zomatoList.setResultsFound(zomatoList.getRestaurants().size());
					zomatoList.setResultsShown(zomatoList.getRestaurants().size());
				} else {
					log.info("Information incorrect. Please provide correct information.");
				}
			}
		} catch (Exception e) {

			log.info("Static file read : " + e.getMessage());
		}
		return zomatoList;
	}

}
