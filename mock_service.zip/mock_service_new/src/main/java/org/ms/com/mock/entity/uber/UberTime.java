
package org.ms.com.mock.entity.uber;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "times"
})
public class UberTime {

    @JsonProperty("times")
    private List<Time> times = null;

    @JsonProperty("times")
    public List<Time> getTimes() {
        return times;
    }

    @JsonProperty("times")
    public void setTimes(List<Time> times) {
        this.times = times;
    }

}
