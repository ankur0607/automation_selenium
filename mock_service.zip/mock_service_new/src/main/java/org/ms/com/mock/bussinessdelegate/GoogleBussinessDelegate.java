package org.ms.com.mock.bussinessdelegate;

import java.util.Map;

import org.ms.com.mock.entity.google.Google;

public interface GoogleBussinessDelegate {
	public Google nearBy(Map<String, String> requestParam);
}
