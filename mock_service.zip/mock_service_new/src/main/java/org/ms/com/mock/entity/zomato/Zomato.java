
package org.ms.com.mock.entity.zomato;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({
    "results_found",
    "results_start",
    "results_shown",
    "restaurants"
})
public class Zomato {

    @JsonProperty("results_found")
    private int resultsFound;
    @JsonProperty("results_start")
    private int resultsStart;
    @JsonProperty("results_shown")
    private int resultsShown;
    @JsonProperty("restaurants")
    private List<Restaurant> restaurants = null;

    @JsonProperty("results_found")
    public int getResultsFound() {
        return resultsFound;
    }

    @JsonProperty("results_found")
    public void setResultsFound(int resultsFound) {
        this.resultsFound = resultsFound;
    }

    @JsonProperty("results_start")
    public int getResultsStart() {
        return resultsStart;
    }

    @JsonProperty("results_start")
    public void setResultsStart(int resultsStart) {
        this.resultsStart = resultsStart;
    }

    @JsonProperty("results_shown")
    public int getResultsShown() {
        return resultsShown;
    }

    @JsonProperty("results_shown")
    public void setResultsShown(int resultsShown) {
        this.resultsShown = resultsShown;
    }

    @JsonProperty("restaurants")
    public List<Restaurant> getRestaurants() {
        return restaurants;
    }

    @JsonProperty("restaurants")
    public void setRestaurants(List<Restaurant> restaurants) {
        this.restaurants = restaurants;
    }

}
