
package org.ms.com.mock.entity.ps;

import com.fasterxml.jackson.annotation.JsonProperty;


public class MerchantLocation {

    @JsonProperty("latitude")
    private String latitude;
    @JsonProperty("longitude")
    private String longitude;
    @JsonProperty("merchantAddress")
    private String merchantAddress;

    @JsonProperty("latitude")
    public String getLatitude() {
        return latitude;
    }

    @JsonProperty("latitude")
    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    @JsonProperty("longitude")
    public String getLongitude() {
        return longitude;
    }

    @JsonProperty("longitude")
    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    @JsonProperty("merchantAddress")
    public String getMerchantAddress() {
        return merchantAddress;
    }

    @JsonProperty("merchantAddress")
    public void setMerchantAddress(String merchantAddress) {
        this.merchantAddress = merchantAddress;
    }

}
