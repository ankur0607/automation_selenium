
package org.ms.com.mock.entity.ola;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


@JsonPropertyOrder({
    "is_hotpot_zone",
    "desc",
    "default_pickup_point_id",
    "hotspot_boundary",
    "pickup_points"
})
public class HotspotZone {

    @JsonProperty("is_hotpot_zone")
    private boolean isHotpotZone;
    @JsonProperty("desc")
    private String desc;
    @JsonProperty("default_pickup_point_id")
    private int defaultPickupPointId;
    @JsonProperty("hotspot_boundary")
    private List<List<Double>> hotspotBoundary = null;
    @JsonProperty("pickup_points")
    private List<PickupPoint> pickupPoints = null;

    @JsonProperty("is_hotpot_zone")
    public boolean isIsHotpotZone() {
        return isHotpotZone;
    }

    @JsonProperty("is_hotpot_zone")
    public void setIsHotpotZone(boolean isHotpotZone) {
        this.isHotpotZone = isHotpotZone;
    }

    @JsonProperty("desc")
    public String getDesc() {
        return desc;
    }

    @JsonProperty("desc")
    public void setDesc(String desc) {
        this.desc = desc;
    }

    @JsonProperty("default_pickup_point_id")
    public int getDefaultPickupPointId() {
        return defaultPickupPointId;
    }

    @JsonProperty("default_pickup_point_id")
    public void setDefaultPickupPointId(int defaultPickupPointId) {
        this.defaultPickupPointId = defaultPickupPointId;
    }

    @JsonProperty("hotspot_boundary")
    public List<List<Double>> getHotspotBoundary() {
        return hotspotBoundary;
    }

    @JsonProperty("hotspot_boundary")
    public void setHotspotBoundary(List<List<Double>> hotspotBoundary) {
        this.hotspotBoundary = hotspotBoundary;
    }

    @JsonProperty("pickup_points")
    public List<PickupPoint> getPickupPoints() {
        return pickupPoints;
    }

    @JsonProperty("pickup_points")
    public void setPickupPoints(List<PickupPoint> pickupPoints) {
        this.pickupPoints = pickupPoints;
    }

}
