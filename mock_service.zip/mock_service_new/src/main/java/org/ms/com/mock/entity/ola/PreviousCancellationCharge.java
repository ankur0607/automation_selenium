
package org.ms.com.mock.entity.ola;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


@JsonPropertyOrder({
    "currency",
    "booking_id",
    "amount"
})
public class PreviousCancellationCharge {

    @JsonProperty("currency")
    private String currency;
    @JsonProperty("booking_id")
    private String bookingId;
    @JsonProperty("amount")
    private int amount;

    @JsonProperty("currency")
    public String getCurrency() {
        return currency;
    }

    @JsonProperty("currency")
    public void setCurrency(String currency) {
        this.currency = currency;
    }

    @JsonProperty("booking_id")
    public String getBookingId() {
        return bookingId;
    }

    @JsonProperty("booking_id")
    public void setBookingId(String bookingId) {
        this.bookingId = bookingId;
    }

    @JsonProperty("amount")
    public int getAmount() {
        return amount;
    }

    @JsonProperty("amount")
    public void setAmount(int amount) {
        this.amount = amount;
    }

}
