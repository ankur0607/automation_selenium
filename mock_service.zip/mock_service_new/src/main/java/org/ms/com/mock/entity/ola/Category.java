
package org.ms.com.mock.entity.ola;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


@JsonPropertyOrder({
    "id",
    "display_name",
    "currency",
    "distance_unit",
    "time_unit",
    "eta",
    "distance",
    "ride_later_enabled",
    "image",
    "hotspot_pickup_points",
    "cancellation_policy",
    "fare_breakup",
    "all_cabs"
})
public class Category {

    @JsonProperty("id")
    private String id;
    @JsonProperty("display_name")
    private String displayName;
    @JsonProperty("currency")
    private String currency;
    @JsonProperty("distance_unit")
    private String distanceUnit;
    @JsonProperty("time_unit")
    private String timeUnit;
    @JsonProperty("eta")
    private int eta;
    @JsonProperty("distance")
    private String distance;
    @JsonProperty("ride_later_enabled")
    private String rideLaterEnabled;
    @JsonProperty("image")
    private String image;
    @JsonProperty("hotspot_pickup_points")
    private List<Integer> hotspotPickupPoints = null;
    @JsonProperty("cancellation_policy")
    private CancellationPolicy cancellationPolicy;
    @JsonProperty("fare_breakup")
    private List<FareBreakup> fareBreakup = null;
    @JsonProperty("all_cabs")
    private List<AllCab> allCabs = null;

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    @JsonProperty("display_name")
    public String getDisplayName() {
        return displayName;
    }

    @JsonProperty("display_name")
    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    @JsonProperty("currency")
    public String getCurrency() {
        return currency;
    }

    @JsonProperty("currency")
    public void setCurrency(String currency) {
        this.currency = currency;
    }

    @JsonProperty("distance_unit")
    public String getDistanceUnit() {
        return distanceUnit;
    }

    @JsonProperty("distance_unit")
    public void setDistanceUnit(String distanceUnit) {
        this.distanceUnit = distanceUnit;
    }

    @JsonProperty("time_unit")
    public String getTimeUnit() {
        return timeUnit;
    }

    @JsonProperty("time_unit")
    public void setTimeUnit(String timeUnit) {
        this.timeUnit = timeUnit;
    }

    @JsonProperty("eta")
    public int getEta() {
        return eta;
    }

    @JsonProperty("eta")
    public void setEta(int eta) {
        this.eta = eta;
    }

    @JsonProperty("distance")
    public String getDistance() {
        return distance;
    }

    @JsonProperty("distance")
    public void setDistance(String distance) {
        this.distance = distance;
    }

    @JsonProperty("ride_later_enabled")
    public String getRideLaterEnabled() {
        return rideLaterEnabled;
    }

    @JsonProperty("ride_later_enabled")
    public void setRideLaterEnabled(String rideLaterEnabled) {
        this.rideLaterEnabled = rideLaterEnabled;
    }

    @JsonProperty("image")
    public String getImage() {
        return image;
    }

    @JsonProperty("image")
    public void setImage(String image) {
        this.image = image;
    }

    @JsonProperty("hotspot_pickup_points")
    public List<Integer> getHotspotPickupPoints() {
        return hotspotPickupPoints;
    }

    @JsonProperty("hotspot_pickup_points")
    public void setHotspotPickupPoints(List<Integer> hotspotPickupPoints) {
        this.hotspotPickupPoints = hotspotPickupPoints;
    }

    @JsonProperty("cancellation_policy")
    public CancellationPolicy getCancellationPolicy() {
        return cancellationPolicy;
    }

    @JsonProperty("cancellation_policy")
    public void setCancellationPolicy(CancellationPolicy cancellationPolicy) {
        this.cancellationPolicy = cancellationPolicy;
    }

    @JsonProperty("fare_breakup")
    public List<FareBreakup> getFareBreakup() {
        return fareBreakup;
    }

    @JsonProperty("fare_breakup")
    public void setFareBreakup(List<FareBreakup> fareBreakup) {
        this.fareBreakup = fareBreakup;
    }

    @JsonProperty("all_cabs")
    public List<AllCab> getAllCabs() {
        return allCabs;
    }

    @JsonProperty("all_cabs")
    public void setAllCabs(List<AllCab> allCabs) {
        this.allCabs = allCabs;
    }

}
