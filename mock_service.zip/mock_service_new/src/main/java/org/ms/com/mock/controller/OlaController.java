package org.ms.com.mock.controller;

import java.util.Map;

import org.ms.com.mock.bussinessdelegate.OlaBussinessDelegate;
import org.ms.com.mock.entity.ola.Ola;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class OlaController {

	@Autowired
	OlaBussinessDelegate olaBussinessDelegate;

	@GetMapping(value = "/ola")
	public Ola rideEstimate(@RequestParam Map<String, String> requestParam) {

		return olaBussinessDelegate.getRideEstimation(requestParam);

	}

}
