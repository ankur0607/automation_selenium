
package org.ms.com.mock.entity.ola;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


@JsonPropertyOrder({
    "hotspot_zone",
    "categories",
    "ride_estimate",
    "previous_cancellation_charges"
})
public class Ola {

    @JsonProperty("hotspot_zone")
    private HotspotZone hotspotZone;
    @JsonProperty("categories")
    private List<Category> categories = null;
    @JsonProperty("ride_estimate")
    private List<RideEstimate> rideEstimate = null;
    @JsonProperty("previous_cancellation_charges")
    private List<PreviousCancellationCharge> previousCancellationCharges = null;

    @JsonProperty("hotspot_zone")
    public HotspotZone getHotspotZone() {
        return hotspotZone;
    }

    @JsonProperty("hotspot_zone")
    public void setHotspotZone(HotspotZone hotspotZone) {
        this.hotspotZone = hotspotZone;
    }

    @JsonProperty("categories")
    public List<Category> getCategories() {
        return categories;
    }

    @JsonProperty("categories")
    public void setCategories(List<Category> categories) {
        this.categories = categories;
    }

    @JsonProperty("ride_estimate")
    public List<RideEstimate> getRideEstimate() {
        return rideEstimate;
    }

    @JsonProperty("ride_estimate")
    public void setRideEstimate(List<RideEstimate> rideEstimate) {
        this.rideEstimate = rideEstimate;
    }

    @JsonProperty("previous_cancellation_charges")
    public List<PreviousCancellationCharge> getPreviousCancellationCharges() {
        return previousCancellationCharges;
    }

    @JsonProperty("previous_cancellation_charges")
    public void setPreviousCancellationCharges(List<PreviousCancellationCharge> previousCancellationCharges) {
        this.previousCancellationCharges = previousCancellationCharges;
    }

}
