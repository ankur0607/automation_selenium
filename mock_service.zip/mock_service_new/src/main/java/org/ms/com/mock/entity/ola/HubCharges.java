
package org.ms.com.mock.entity.ola;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


@JsonPropertyOrder({
    "total_hub_fee",
    "pickup_hub_fee",
    "pickup_hub_name"
})
public class HubCharges {

    @JsonProperty("total_hub_fee")
    private int totalHubFee;
    @JsonProperty("pickup_hub_fee")
    private int pickupHubFee;
    @JsonProperty("pickup_hub_name")
    private String pickupHubName;

    @JsonProperty("total_hub_fee")
    public int getTotalHubFee() {
        return totalHubFee;
    }

    @JsonProperty("total_hub_fee")
    public void setTotalHubFee(int totalHubFee) {
        this.totalHubFee = totalHubFee;
    }

    @JsonProperty("pickup_hub_fee")
    public int getPickupHubFee() {
        return pickupHubFee;
    }

    @JsonProperty("pickup_hub_fee")
    public void setPickupHubFee(int pickupHubFee) {
        this.pickupHubFee = pickupHubFee;
    }

    @JsonProperty("pickup_hub_name")
    public String getPickupHubName() {
        return pickupHubName;
    }

    @JsonProperty("pickup_hub_name")
    public void setPickupHubName(String pickupHubName) {
        this.pickupHubName = pickupHubName;
    }

}
