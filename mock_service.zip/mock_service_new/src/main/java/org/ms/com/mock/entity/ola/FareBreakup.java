
package org.ms.com.mock.entity.ola;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


@JsonPropertyOrder({
    "type",
    "minimum_distance",
    "minimum_time",
    "base_fare",
    "minimum_fare",
    "cost_per_distance",
    "waiting_cost_per_minute",
    "ride_cost_per_minute",
    "surcharge",
    "rates_lower_than_usual",
    "rates_higher_than_usual"
})
public class FareBreakup {

    @JsonProperty("type")
    private String type;
    @JsonProperty("minimum_distance")
    private int minimumDistance;
    @JsonProperty("minimum_time")
    private int minimumTime;
    @JsonProperty("base_fare")
    private int baseFare;
    @JsonProperty("minimum_fare")
    private int minimumFare;
    @JsonProperty("cost_per_distance")
    private int costPerDistance;
    @JsonProperty("waiting_cost_per_minute")
    private int waitingCostPerMinute;
    @JsonProperty("ride_cost_per_minute")
    private int rideCostPerMinute;
    @JsonProperty("surcharge")
    private List<Object> surcharge = null;
    @JsonProperty("rates_lower_than_usual")
    private boolean ratesLowerThanUsual;
    @JsonProperty("rates_higher_than_usual")
    private boolean ratesHigherThanUsual;

    @JsonProperty("type")
    public String getType() {
        return type;
    }

    @JsonProperty("type")
    public void setType(String type) {
        this.type = type;
    }

    @JsonProperty("minimum_distance")
    public int getMinimumDistance() {
        return minimumDistance;
    }

    @JsonProperty("minimum_distance")
    public void setMinimumDistance(int minimumDistance) {
        this.minimumDistance = minimumDistance;
    }

    @JsonProperty("minimum_time")
    public int getMinimumTime() {
        return minimumTime;
    }

    @JsonProperty("minimum_time")
    public void setMinimumTime(int minimumTime) {
        this.minimumTime = minimumTime;
    }

    @JsonProperty("base_fare")
    public int getBaseFare() {
        return baseFare;
    }

    @JsonProperty("base_fare")
    public void setBaseFare(int baseFare) {
        this.baseFare = baseFare;
    }

    @JsonProperty("minimum_fare")
    public int getMinimumFare() {
        return minimumFare;
    }

    @JsonProperty("minimum_fare")
    public void setMinimumFare(int minimumFare) {
        this.minimumFare = minimumFare;
    }

    @JsonProperty("cost_per_distance")
    public int getCostPerDistance() {
        return costPerDistance;
    }

    @JsonProperty("cost_per_distance")
    public void setCostPerDistance(int costPerDistance) {
        this.costPerDistance = costPerDistance;
    }

    @JsonProperty("waiting_cost_per_minute")
    public int getWaitingCostPerMinute() {
        return waitingCostPerMinute;
    }

    @JsonProperty("waiting_cost_per_minute")
    public void setWaitingCostPerMinute(int waitingCostPerMinute) {
        this.waitingCostPerMinute = waitingCostPerMinute;
    }

    @JsonProperty("ride_cost_per_minute")
    public int getRideCostPerMinute() {
        return rideCostPerMinute;
    }

    @JsonProperty("ride_cost_per_minute")
    public void setRideCostPerMinute(int rideCostPerMinute) {
        this.rideCostPerMinute = rideCostPerMinute;
    }

    @JsonProperty("surcharge")
    public List<Object> getSurcharge() {
        return surcharge;
    }

    @JsonProperty("surcharge")
    public void setSurcharge(List<Object> surcharge) {
        this.surcharge = surcharge;
    }

    @JsonProperty("rates_lower_than_usual")
    public boolean isRatesLowerThanUsual() {
        return ratesLowerThanUsual;
    }

    @JsonProperty("rates_lower_than_usual")
    public void setRatesLowerThanUsual(boolean ratesLowerThanUsual) {
        this.ratesLowerThanUsual = ratesLowerThanUsual;
    }

    @JsonProperty("rates_higher_than_usual")
    public boolean isRatesHigherThanUsual() {
        return ratesHigherThanUsual;
    }

    @JsonProperty("rates_higher_than_usual")
    public void setRatesHigherThanUsual(boolean ratesHigherThanUsual) {
        this.ratesHigherThanUsual = ratesHigherThanUsual;
    }

}
