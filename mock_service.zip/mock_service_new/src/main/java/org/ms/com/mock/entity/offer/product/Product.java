
package org.ms.com.mock.entity.offer.product;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({
    "mastercardProductCode",
    "mastercardProductName",
    "productType"
})
public class Product {

    @JsonProperty("mastercardProductCode")
    private String mastercardProductCode;
    @JsonProperty("mastercardProductName")
    private String mastercardProductName;
    @JsonProperty("productType")
    private String productType;

    @JsonProperty("mastercardProductCode")
    public String getMastercardProductCode() {
        return mastercardProductCode;
    }

    @JsonProperty("mastercardProductCode")
    public void setMastercardProductCode(String mastercardProductCode) {
        this.mastercardProductCode = mastercardProductCode;
    }

    @JsonProperty("mastercardProductName")
    public String getMastercardProductName() {
        return mastercardProductName;
    }

    @JsonProperty("mastercardProductName")
    public void setMastercardProductName(String mastercardProductName) {
        this.mastercardProductName = mastercardProductName;
    }

    @JsonProperty("productType")
    public String getProductType() {
        return productType;
    }

    @JsonProperty("productType")
    public void setProductType(String productType) {
        this.productType = productType;
    }

}
