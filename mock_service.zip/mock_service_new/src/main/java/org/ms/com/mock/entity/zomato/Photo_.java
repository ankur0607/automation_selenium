
package org.ms.com.mock.entity.zomato;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({
    "id",
    "url",
    "thumb_url",
    "user",
    "res_id",
    "caption",
    "timestamp",
    "friendly_time",
    "width",
    "height"
})
public class Photo_ {

    @JsonProperty("id")
    private String id;
    @JsonProperty("url")
    private String url;
    @JsonProperty("thumb_url")
    private String thumbUrl;
    @JsonProperty("user")
    private User user;
    @JsonProperty("res_id")
    private int resId;
    @JsonProperty("caption")
    private String caption;
    @JsonProperty("timestamp")
    private int timestamp;
    @JsonProperty("friendly_time")
    private String friendlyTime;
    @JsonProperty("width")
    private int width;
    @JsonProperty("height")
    private int height;

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    @JsonProperty("url")
    public String getUrl() {
        return url;
    }

    @JsonProperty("url")
    public void setUrl(String url) {
        this.url = url;
    }

    @JsonProperty("thumb_url")
    public String getThumbUrl() {
        return thumbUrl;
    }

    @JsonProperty("thumb_url")
    public void setThumbUrl(String thumbUrl) {
        this.thumbUrl = thumbUrl;
    }

    @JsonProperty("user")
    public User getUser() {
        return user;
    }

    @JsonProperty("user")
    public void setUser(User user) {
        this.user = user;
    }

    @JsonProperty("res_id")
    public int getResId() {
        return resId;
    }

    @JsonProperty("res_id")
    public void setResId(int resId) {
        this.resId = resId;
    }

    @JsonProperty("caption")
    public String getCaption() {
        return caption;
    }

    @JsonProperty("caption")
    public void setCaption(String caption) {
        this.caption = caption;
    }

    @JsonProperty("timestamp")
    public int getTimestamp() {
        return timestamp;
    }

    @JsonProperty("timestamp")
    public void setTimestamp(int timestamp) {
        this.timestamp = timestamp;
    }

    @JsonProperty("friendly_time")
    public String getFriendlyTime() {
        return friendlyTime;
    }

    @JsonProperty("friendly_time")
    public void setFriendlyTime(String friendlyTime) {
        this.friendlyTime = friendlyTime;
    }

    @JsonProperty("width")
    public int getWidth() {
        return width;
    }

    @JsonProperty("width")
    public void setWidth(int width) {
        this.width = width;
    }

    @JsonProperty("height")
    public int getHeight() {
        return height;
    }

    @JsonProperty("height")
    public void setHeight(int height) {
        this.height = height;
    }

}
