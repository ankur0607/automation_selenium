
package org.ms.com.mock.entity.zomato;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({
    "photo"
})
public class Photo {

    @JsonProperty("photo")
    private Photo_ photo;

    @JsonProperty("photo")
    public Photo_ getPhoto() {
        return photo;
    }

    @JsonProperty("photo")
    public void setPhoto(Photo_ photo) {
        this.photo = photo;
    }

}
