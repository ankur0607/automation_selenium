package org.ms.com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MockServiceNewApplication {

	public static void main(String[] args) {
		SpringApplication.run(MockServiceNewApplication.class, args);
	}

}
