
package org.ms.com.mock.entity.zomato;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


@JsonPropertyOrder({
    "delivery",
    "takeaway"
})
public class HasMenuStatus {

    @JsonProperty("delivery")
    private int delivery;
    @JsonProperty("takeaway")
    private int takeaway;

    @JsonProperty("delivery")
    public int getDelivery() {
        return delivery;
    }

    @JsonProperty("delivery")
    public void setDelivery(int delivery) {
        this.delivery = delivery;
    }

    @JsonProperty("takeaway")
    public int getTakeaway() {
        return takeaway;
    }

    @JsonProperty("takeaway")
    public void setTakeaway(int takeaway) {
        this.takeaway = takeaway;
    }

}
