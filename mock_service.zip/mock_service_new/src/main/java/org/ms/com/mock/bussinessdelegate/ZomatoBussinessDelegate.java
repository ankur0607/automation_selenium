package org.ms.com.mock.bussinessdelegate;

import java.util.Map;

import org.ms.com.mock.entity.zomato.Zomato;

public interface ZomatoBussinessDelegate {
	
	public Zomato getRestaurants(Map<String, String> zomatoCriteria);

}
