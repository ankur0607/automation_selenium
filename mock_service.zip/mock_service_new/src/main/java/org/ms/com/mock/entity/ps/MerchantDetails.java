
package org.ms.com.mock.entity.ps;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;


public class MerchantDetails {

    @JsonProperty("merchantCity")
    private String merchantCity;
    @JsonProperty("merchantCountry")
    private String merchantCountry;
    @JsonProperty("merchantCountryCode")
    private String merchantCountryCode;
    @JsonProperty("merchantEmailAddress")
    private String merchantEmailAddress;
    @JsonProperty("merchantLocations")
    private List<MerchantLocation> merchantLocations = null;
    @JsonProperty("merchantName")
    private String merchantName;
    @JsonProperty("merchantPhoneNumber")
    private String merchantPhoneNumber;
    @JsonProperty("merchantWebsite")
    private String merchantWebsite;

    @JsonProperty("merchantCity")
    public String getMerchantCity() {
        return merchantCity;
    }

    @JsonProperty("merchantCity")
    public void setMerchantCity(String merchantCity) {
        this.merchantCity = merchantCity;
    }

    @JsonProperty("merchantCountry")
    public String getMerchantCountry() {
        return merchantCountry;
    }

    @JsonProperty("merchantCountry")
    public void setMerchantCountry(String merchantCountry) {
        this.merchantCountry = merchantCountry;
    }

    @JsonProperty("merchantCountryCode")
    public String getMerchantCountryCode() {
        return merchantCountryCode;
    }

    @JsonProperty("merchantCountryCode")
    public void setMerchantCountryCode(String merchantCountryCode) {
        this.merchantCountryCode = merchantCountryCode;
    }

    @JsonProperty("merchantEmailAddress")
    public String getMerchantEmailAddress() {
        return merchantEmailAddress;
    }

    @JsonProperty("merchantEmailAddress")
    public void setMerchantEmailAddress(String merchantEmailAddress) {
        this.merchantEmailAddress = merchantEmailAddress;
    }

    @JsonProperty("merchantLocations")
    public List<MerchantLocation> getMerchantLocations() {
        return merchantLocations;
    }

    @JsonProperty("merchantLocations")
    public void setMerchantLocations(List<MerchantLocation> merchantLocations) {
        this.merchantLocations = merchantLocations;
    }

    @JsonProperty("merchantName")
    public String getMerchantName() {
        return merchantName;
    }

    @JsonProperty("merchantName")
    public void setMerchantName(String merchantName) {
        this.merchantName = merchantName;
    }

    @JsonProperty("merchantPhoneNumber")
    public String getMerchantPhoneNumber() {
        return merchantPhoneNumber;
    }

    @JsonProperty("merchantPhoneNumber")
    public void setMerchantPhoneNumber(String merchantPhoneNumber) {
        this.merchantPhoneNumber = merchantPhoneNumber;
    }

    @JsonProperty("merchantWebsite")
    public String getMerchantWebsite() {
        return merchantWebsite;
    }

    @JsonProperty("merchantWebsite")
    public void setMerchantWebsite(String merchantWebsite) {
        this.merchantWebsite = merchantWebsite;
    }

}
