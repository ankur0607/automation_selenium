
package org.ms.com.mock.entity.ola;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


@JsonPropertyOrder({
    "cancellation_charge",
    "currency",
    "cancellation_charge_applies_after_time",
    "time_unit"
})
public class CancellationPolicy {

    @JsonProperty("cancellation_charge")
    private int cancellationCharge;
    @JsonProperty("currency")
    private String currency;
    @JsonProperty("cancellation_charge_applies_after_time")
    private int cancellationChargeAppliesAfterTime;
    @JsonProperty("time_unit")
    private String timeUnit;

    @JsonProperty("cancellation_charge")
    public int getCancellationCharge() {
        return cancellationCharge;
    }

    @JsonProperty("cancellation_charge")
    public void setCancellationCharge(int cancellationCharge) {
        this.cancellationCharge = cancellationCharge;
    }

    @JsonProperty("currency")
    public String getCurrency() {
        return currency;
    }

    @JsonProperty("currency")
    public void setCurrency(String currency) {
        this.currency = currency;
    }

    @JsonProperty("cancellation_charge_applies_after_time")
    public int getCancellationChargeAppliesAfterTime() {
        return cancellationChargeAppliesAfterTime;
    }

    @JsonProperty("cancellation_charge_applies_after_time")
    public void setCancellationChargeAppliesAfterTime(int cancellationChargeAppliesAfterTime) {
        this.cancellationChargeAppliesAfterTime = cancellationChargeAppliesAfterTime;
    }

    @JsonProperty("time_unit")
    public String getTimeUnit() {
        return timeUnit;
    }

    @JsonProperty("time_unit")
    public void setTimeUnit(String timeUnit) {
        this.timeUnit = timeUnit;
    }

}
