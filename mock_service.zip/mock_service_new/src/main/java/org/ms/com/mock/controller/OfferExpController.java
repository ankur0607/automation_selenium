package org.ms.com.mock.controller;

import java.util.Map;

import org.ms.com.mock.bussinessdelegate.OfferExpBussinessDelegate;
import org.ms.com.mock.entity.ps.OfferList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class OfferExpController {
	
	@Autowired
	OfferExpBussinessDelegate offerExpBussinessDelegate;
	
	@GetMapping(value = "/ind/offers")
	public OfferList getIndOffers(@RequestParam Map<String,String> requestParam)
	{
		return  offerExpBussinessDelegate.getIndOffers(requestParam);
	}

}
