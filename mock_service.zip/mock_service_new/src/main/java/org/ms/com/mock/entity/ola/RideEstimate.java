
package org.ms.com.mock.entity.ola;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


@JsonPropertyOrder({
    "category",
    "distance",
    "travel_time_in_minutes",
    "amount_min",
    "amount_max",
    "booking_fee",
    "booking_fee_breakup",
    "taxes",
    "hub_charges",
    "discounts",
    "upfront"
})
public class RideEstimate {

    @JsonProperty("category")
    private String category;
    @JsonProperty("distance")
    private double distance;
    @JsonProperty("travel_time_in_minutes")
    private int travelTimeInMinutes;
    @JsonProperty("amount_min")
    private int amountMin;
    @JsonProperty("amount_max")
    private int amountMax;
    @JsonProperty("booking_fee")
    private int bookingFee;
    @JsonProperty("booking_fee_breakup")
    private List<BookingFeeBreakup> bookingFeeBreakup = null;
    @JsonProperty("taxes")
    private Taxes taxes;
    @JsonProperty("hub_charges")
    private HubCharges hubCharges;
    @JsonProperty("discounts")
    private Discounts discounts;
    @JsonProperty("upfront")
    private Upfront upfront;

    @JsonProperty("category")
    public String getCategory() {
        return category;
    }

    @JsonProperty("category")
    public void setCategory(String category) {
        this.category = category;
    }

    @JsonProperty("distance")
    public double getDistance() {
        return distance;
    }

    @JsonProperty("distance")
    public void setDistance(double distance) {
        this.distance = distance;
    }

    @JsonProperty("travel_time_in_minutes")
    public int getTravelTimeInMinutes() {
        return travelTimeInMinutes;
    }

    @JsonProperty("travel_time_in_minutes")
    public void setTravelTimeInMinutes(int travelTimeInMinutes) {
        this.travelTimeInMinutes = travelTimeInMinutes;
    }

    @JsonProperty("amount_min")
    public int getAmountMin() {
        return amountMin;
    }

    @JsonProperty("amount_min")
    public void setAmountMin(int amountMin) {
        this.amountMin = amountMin;
    }

    @JsonProperty("amount_max")
    public int getAmountMax() {
        return amountMax;
    }

    @JsonProperty("amount_max")
    public void setAmountMax(int amountMax) {
        this.amountMax = amountMax;
    }

    @JsonProperty("booking_fee")
    public int getBookingFee() {
        return bookingFee;
    }

    @JsonProperty("booking_fee")
    public void setBookingFee(int bookingFee) {
        this.bookingFee = bookingFee;
    }

    @JsonProperty("booking_fee_breakup")
    public List<BookingFeeBreakup> getBookingFeeBreakup() {
        return bookingFeeBreakup;
    }

    @JsonProperty("booking_fee_breakup")
    public void setBookingFeeBreakup(List<BookingFeeBreakup> bookingFeeBreakup) {
        this.bookingFeeBreakup = bookingFeeBreakup;
    }

    @JsonProperty("taxes")
    public Taxes getTaxes() {
        return taxes;
    }

    @JsonProperty("taxes")
    public void setTaxes(Taxes taxes) {
        this.taxes = taxes;
    }

    @JsonProperty("hub_charges")
    public HubCharges getHubCharges() {
        return hubCharges;
    }

    @JsonProperty("hub_charges")
    public void setHubCharges(HubCharges hubCharges) {
        this.hubCharges = hubCharges;
    }

    @JsonProperty("discounts")
    public Discounts getDiscounts() {
        return discounts;
    }

    @JsonProperty("discounts")
    public void setDiscounts(Discounts discounts) {
        this.discounts = discounts;
    }

    @JsonProperty("upfront")
    public Upfront getUpfront() {
        return upfront;
    }

    @JsonProperty("upfront")
    public void setUpfront(Upfront upfront) {
        this.upfront = upfront;
    }

}
