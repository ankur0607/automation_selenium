
package org.ms.com.mock.entity.uber;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "localized_display_name",
    "distance",
    "display_name",
    "product_id",
    "high_estimate",
    "low_estimate",
    "duration",
    "estimate",
    "currency_code"
})
public class Price {

    @JsonProperty("localized_display_name")
    private String localizedDisplayName;
    @JsonProperty("distance")
    private double distance;
    @JsonProperty("display_name")
    private String displayName;
    @JsonProperty("product_id")
    private String productId;
    @JsonProperty("high_estimate")
    private Object highEstimate;
    @JsonProperty("low_estimate")
    private Object lowEstimate;
    @JsonProperty("duration")
    private int duration;
    @JsonProperty("estimate")
    private String estimate;
    @JsonProperty("currency_code")
    private Object currencyCode;

    @JsonProperty("localized_display_name")
    public String getLocalizedDisplayName() {
        return localizedDisplayName;
    }

    @JsonProperty("localized_display_name")
    public void setLocalizedDisplayName(String localizedDisplayName) {
        this.localizedDisplayName = localizedDisplayName;
    }

    @JsonProperty("distance")
    public double getDistance() {
        return distance;
    }

    @JsonProperty("distance")
    public void setDistance(double distance) {
        this.distance = distance;
    }

    @JsonProperty("display_name")
    public String getDisplayName() {
        return displayName;
    }

    @JsonProperty("display_name")
    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    @JsonProperty("product_id")
    public String getProductId() {
        return productId;
    }

    @JsonProperty("product_id")
    public void setProductId(String productId) {
        this.productId = productId;
    }

    @JsonProperty("high_estimate")
    public Object getHighEstimate() {
        return highEstimate;
    }

    @JsonProperty("high_estimate")
    public void setHighEstimate(Object highEstimate) {
        this.highEstimate = highEstimate;
    }

    @JsonProperty("low_estimate")
    public Object getLowEstimate() {
        return lowEstimate;
    }

    @JsonProperty("low_estimate")
    public void setLowEstimate(Object lowEstimate) {
        this.lowEstimate = lowEstimate;
    }

    @JsonProperty("duration")
    public int getDuration() {
        return duration;
    }

    @JsonProperty("duration")
    public void setDuration(int duration) {
        this.duration = duration;
    }

    @JsonProperty("estimate")
    public String getEstimate() {
        return estimate;
    }

    @JsonProperty("estimate")
    public void setEstimate(String estimate) {
        this.estimate = estimate;
    }

    @JsonProperty("currency_code")
    public Object getCurrencyCode() {
        return currencyCode;
    }

    @JsonProperty("currency_code")
    public void setCurrencyCode(Object currencyCode) {
        this.currencyCode = currencyCode;
    }

}
