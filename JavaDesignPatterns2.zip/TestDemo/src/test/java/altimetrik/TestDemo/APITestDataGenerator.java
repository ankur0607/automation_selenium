package altimetrik.TestDemo;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import static org.hamcrest.Matchers.*;

import org.json.*;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import groovyjarjarantlr.LexerSharedInputState;
import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.internal.path.json.JSONAssertion;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class APITestDataGenerator {

	static FileReader fr;
	static BufferedReader br;
	static List<String> list;
	static List<String> requiredPropsList;
	static List<String> headerParamList;
	static Map<String, String> headerMap;
	static Map<String, Object> requiredPropsMap;
	static Map<String, Object> notRequiredPropsMap;
	static Map<String, Object> defaultValueForNotRequiredPropsMap;
	static Map<String, String> requiredPropsTypeMap;
	static Map<String, String> notRequiredPropsTypeMap;
	static List<String> notRequiredPropsList;
	static List<String> requiredPropsDataTypeList;
	static String[] stockArr;
	static JSONArray jsonArray;
	static JSONObject[] tempObjs;
	static JSONObject[] jo;
	static Properties configProps;
	static String path;
	static String exampleRAMLFile;
	static String RAMLFile;
	static String RAML2JSONFile;
	static String RAMLS;
	static String EXAMPLES;
	static String files;
	static String responseFiles;
	static String responseInDF;
	
	static int totalRequired;
	static int totalNotRequired;
	static String blankValueData;
	static String invalidValueData;
	static String notHavingPropertyData;
	static List<JSONObject> queryParamsJsonList;
	static List<String> propertiesRefList;

	public static void main(String[] args) throws IOException, ParseException {
		
		//readYamlFile("experience-merchant-offer.yaml");
		
		//System.out.println(getCompleteData());
		
		/*
		 * try (FileWriter file = new
		 * FileWriter(System.getProperty("user.dir")+"\\test-data\\api_testdata.json"))
		 * { file.write(getCompleteData().toJSONString()); }
		 */

		//tc1_verify_system_api_spec_get_request();
		
		tc2_verify_zomato_restaurants_review();

	}

	@SuppressWarnings("unchecked")
	static JSONArray getCompleteData() {

		JSONArray dataJsonArray = new JSONArray();

		for (JSONObject o : getQueryParamsObjects()) {
			dataJsonArray.add(o);
		}

		for (JSONObject o : getInvalidHeadersValueData()) {
			dataJsonArray.add(o);
		}

		for (JSONObject o : getMissingHeadersValueData()) {
			dataJsonArray.add(o);
		}

		return dataJsonArray;
	}

	// Preparing data json array (i.e. number of data on a place only) by collecting all query params, header params and validity of data
	@SuppressWarnings("unchecked")
	static JSONObject[] getQueryParamsObjects() {
		storeAllQueryParamsData();
		JSONObject queryParams[] = new JSONObject[queryParamsJsonList.size()];

		for (int i = 0; i < queryParamsJsonList.size(); i++) {
			queryParams[i] = new JSONObject();
			queryParams[i].put("queryParams", queryParamsJsonList.get(i));
			if (i == queryParamsJsonList.size() - 1) {
				queryParams[i].put("valid", true);
				queryParams[i].put("headerParams", getHeaderObject());
			} else {
				queryParams[i].put("valid", false);
				queryParams[i].put("headerParams", getHeaderObject());
			}

		}

		return queryParams;

	}

	// Storing all type of query parameters objects in JSON array
	static void storeAllQueryParamsData() {

		queryParamsJsonList = new ArrayList<JSONObject>();
		for (JSONObject o : getMissingValueBodyObjects()) {
			queryParamsJsonList.add(o);
		}

		for (JSONObject o : getInvalidValueBodyObjects()) {
			queryParamsJsonList.add(o);
		}

		queryParamsJsonList.add(getValidBodyObject());

	}

	// Getting object of query parameters with invalid values
	@SuppressWarnings("unchecked")
	static JSONObject[] getInvalidValueBodyObjects() {

		JSONObject[] invalidObjects = new JSONObject[requiredPropsList.size()];

		for (int i = 0; i < invalidObjects.length; i++) {
			invalidObjects[i] = new JSONObject();
			for (int j = 0; j < requiredPropsList.size(); j++) {
				if (i == j && requiredPropsTypeMap.get(requiredPropsList.get(j)).equals("number")) {
					invalidObjects[i].put(requiredPropsList.get(j),
							requiredPropsMap.get(requiredPropsList.get(j)).toString());
				} else {
					invalidObjects[i].put(requiredPropsList.get(j), requiredPropsMap.get(requiredPropsList.get(j)));
				}

			}
		}

		return invalidObjects;

	}

	// Getting object of query parameters for missing values
	@SuppressWarnings("unchecked")
	static JSONObject[] getMissingValueBodyObjects() {

		JSONObject[] missingObjects = new JSONObject[requiredPropsList.size()];

		for (int i = 0; i < missingObjects.length; i++) {
			missingObjects[i] = new JSONObject();
			for (int j = 0; j < requiredPropsList.size(); j++) {
				if (i == j) {
					missingObjects[i].put(requiredPropsList.get(j), "");
				} else {
					missingObjects[i].put(requiredPropsList.get(j), requiredPropsMap.get(requiredPropsList.get(j)));
				}
			}
		}

		return missingObjects;

	}

	// Getting object of header parameters with invalid value
	@SuppressWarnings("unchecked")
	static JSONObject[] getInvalidHeadersValueData() {

		JSONObject[] invalidHeaderDataObjects = new JSONObject[headerMap.size()];

		for (int i = 0; i < invalidHeaderDataObjects.length; i++) {
			invalidHeaderDataObjects[i] = new JSONObject();
			JSONObject tempJsonObj = new JSONObject();
			for (int j = 0; j < headerParamList.size(); j++) {
				if (i == j) {
					tempJsonObj.put(headerParamList.get(j), "InvalidHeaderValue");
				} else {
					tempJsonObj.put(headerParamList.get(j), headerMap.get(headerParamList.get(j)));
				}
			}
			invalidHeaderDataObjects[i].put("headerParams", tempJsonObj);
			invalidHeaderDataObjects[i].put("queryParams", getValidBodyObject());
			invalidHeaderDataObjects[i].put("valid", false);
		}

		return invalidHeaderDataObjects;

	}

	// Getting object of header parameters missing with value
	@SuppressWarnings("unchecked")
	static JSONObject[] getMissingHeadersValueData() {

		JSONObject[] missingHeaderDataObjects = new JSONObject[headerMap.size()];

		for (int i = 0; i < missingHeaderDataObjects.length; i++) {
			missingHeaderDataObjects[i] = new JSONObject();
			JSONObject tempJsonObj = new JSONObject();
			for (int j = 0; j < headerParamList.size(); j++) {
				if (i == j) {
					tempJsonObj.put(headerParamList.get(j), "");
				} else {
					tempJsonObj.put(headerParamList.get(j), headerMap.get(headerParamList.get(j)));
				}
			}
			missingHeaderDataObjects[i].put("headerParams", tempJsonObj);
			missingHeaderDataObjects[i].put("queryParams", getValidBodyObject());
			missingHeaderDataObjects[i].put("valid", false);
		}

		return missingHeaderDataObjects;

	}

	// Getting header parameters object
	@SuppressWarnings("unchecked")
	static JSONObject getHeaderObject() {

		JSONObject headerObj = new JSONObject();

		for (Entry<String, String> h : headerMap.entrySet()) {
			headerObj.put(h.getKey(), h.getValue());
		}

		return headerObj;

	}

	// Getting valid query parameters object for required qparams only
	@SuppressWarnings("unchecked")
	static JSONObject getValidBodyObject() {

		JSONObject validBodyObj = new JSONObject();

		for (Entry<String, Object> h : requiredPropsMap.entrySet()) {
			validBodyObj.put(h.getKey(), h.getValue());
		}
		/*for (Entry<String, Object> h : notRequiredPropsMap.entrySet()) {
			validBodyObj.put(h.getKey(), h.getValue());
		}*/

		return validBodyObj;

	}

	static void readYamlFile(String fileName) throws IOException {

		fr = new FileReader(System.getProperty("user.dir") + "/files/" + fileName);
		br = new BufferedReader(fr);
		list = new ArrayList<String>();
		headerParamList = new ArrayList<String>();
		requiredPropsList = new ArrayList<String>();
		notRequiredPropsList = new ArrayList<String>();
		requiredPropsDataTypeList = new ArrayList<String>();
		headerMap = new HashMap<String, String>();
		requiredPropsMap = new HashMap<String, Object>();
		requiredPropsTypeMap = new HashMap<String, String>();
		notRequiredPropsMap = new HashMap<String, Object>();
		defaultValueForNotRequiredPropsMap = new HashMap<String, Object>();
		notRequiredPropsTypeMap = new HashMap<String, String>();
		propertiesRefList = new ArrayList<String>();

		// Storing all parameters with their values as a line in "propertiesList"
		String line = br.readLine();
		while (line != null) {

			if (line != null && line.trim().contains("#/components/parameters/")) {
				// line = br.readLine();
				propertiesRefList.add(line.split(":")[1].trim());
			}
			if (line.trim().equalsIgnoreCase("responses:"))
				break;
			line = br.readLine();

		}

		// Storing parameters' name and their metadata with respective value of
		// parameters in "propNameList" and Map<String, HashMap<String, String>> q
		// respectively
		Map<String, HashMap<String, String>> q = new HashMap<String, HashMap<String, String>>();
		List<String> propsNameList = new ArrayList<String>();

		String name = "";
		HashMap<String, String> h = null;
		for (String s : propertiesRefList) {

			name = s.split("/")[s.split("/").length - 1].trim().substring(0,
					s.split("/")[s.split("/").length - 1].length() - 1);
			propsNameList.add(name);

		}

		while (line != null) {

			/*
			 * if(line.trim().equals("components:")) { h = new HashMap<String, String>();
			 * line = br.readLine();line = br.readLine(); String nm =
			 * line.trim().substring(0, line.trim().length()-1);
			 * while(!line.contains("parameters:")) { line =
			 * br.readLine();System.out.println(line); h.put(line.split(":")[0].trim(),
			 * line.split(":")[1].trim()); } q.put(nm, h); }
			 */
			for (String p : propsNameList) {

				h = new HashMap<String, String>();
				if (line.trim().endsWith(p + ":")) {

					line = br.readLine();
					while (line != null) {

						if (line.contains(":") && line.trim().split(":").length > 1) {
							h.put(line.split(":")[0].trim(), line.split(":")[1].trim());
						}
						if (line.trim().startsWith("example:")) {
							/*
							 * if(line.split(":")[1].trim().contains(",")) {
							 * h.put(line.split(":")[0].trim(),
							 * line.split(":")[1].trim().split(",")[0].trim()); }else {
							 */
							h.put(line.split(":")[0].trim(), line.split(":")[1].trim());
							// }

							break;
						}
						line = br.readLine();
					}
					q.putIfAbsent(p, h);
				}

			}
			if (q.size() == propsNameList.size()) {
				// System.out.println(line);
				break;
			}

			line = br.readLine();
		}
		// System.out.println(q.entrySet());
		// Storing all required, not-required, data-types and example-values in
		// respective maps
		for (int i = 0; i < propsNameList.size(); i++) {

			// storing header parameters with their respective example value in headerMap
			// storing header parameters in headerParamList
			if (q.get(propsNameList.get(i)).get("in").equalsIgnoreCase("header")) {
				headerMap.put(q.get(propsNameList.get(i)).get("name"), q.get(propsNameList.get(i)).get("example"));
				headerParamList.add(q.get(propsNameList.get(i)).get("name"));
			}

			// storing required properties with their respective example values in requiredPropsMap
			// storing required properties in requiredPropsList
			// storing required properties and their respective types in requiredPropsTypeMap
			
			if (q.get(propsNameList.get(i)).get("in").equalsIgnoreCase("query")
					&& q.get(propsNameList.get(i)).get("required").equalsIgnoreCase("true")) {
				requiredPropsList.add(q.get(propsNameList.get(i)).get("name"));
				if (q.get(propsNameList.get(i)).get("type").equalsIgnoreCase("number")
						|| q.get(propsNameList.get(i)).get("type").equalsIgnoreCase("integer"))
					requiredPropsMap.put(q.get(propsNameList.get(i)).get("name"),
							Double.parseDouble(q.get(propsNameList.get(i)).get("example")));
				else
					requiredPropsMap.put(q.get(propsNameList.get(i)).get("name"),
							q.get(propsNameList.get(i)).get("example"));

				requiredPropsTypeMap.put(q.get(propsNameList.get(i)).get("name"),
						q.get(propsNameList.get(i)).get("type"));
			}

			// storing not-required properties with their respective example values in notRequiredPropsMap
			// storing not-required properties in notRequiredPropsList
			// storing not-required properties and their respective types in notRequiredPropsTypeMap
			
			if (q.get(propsNameList.get(i)).get("in").equalsIgnoreCase("query")
					&& q.get(propsNameList.get(i)).get("required").equalsIgnoreCase("false")) {
				notRequiredPropsList.add(q.get(propsNameList.get(i)).get("name"));
				if (q.get(propsNameList.get(i)).get("type").equalsIgnoreCase("number")
						|| q.get(propsNameList.get(i)).get("type").equalsIgnoreCase("integer"))
					notRequiredPropsMap.put(q.get(propsNameList.get(i)).get("name"),
							Double.parseDouble(q.get(propsNameList.get(i)).get("example")));
				else
					notRequiredPropsMap.put(q.get(propsNameList.get(i)).get("name"),
							q.get(propsNameList.get(i)).get("example"));

				notRequiredPropsTypeMap.put(q.get(propsNameList.get(i)).get("name"),
						q.get(propsNameList.get(i)).get("type"));
			}

		}
		
		/*List<String> expectedProperties = new ArrayList<String>();
		while (!line.trim().equals("Error:")) {

			if (line.trim().equals("schemas:")) {
				line = br.readLine();
				while (!line.trim().equals("Error:")) {
					
					if (line.trim().endsWith(":") && !line.trim().equals("properties:") && !line.trim().equals("items:")) {
						expectedProperties.add(line.split(":")[0].trim());
					}
					if (line.contains(":") && line.split(":").length > 1 && !line.trim().endsWith(":")) {
						//System.out.println(line);
					}
				
					line = br.readLine();
				}

			} else {
				line = br.readLine();
			}
			
		}
		System.out.println(expectedProperties);*/
		System.out.println(requiredPropsList);
		System.out.println(notRequiredPropsList);
		System.out.println(headerParamList);
		
		br.close();
		fr.close();

	}

	static JSONParser jsonParser = new JSONParser();
	static Object obj = null;
	static JSONArray ja = null;
	static RequestSpecBuilder requestBuilder;
	static RequestSpecification requestSpec;
	static ResponseSpecBuilder respBuilder;
	static ResponseSpecification respSpecification;

	@SuppressWarnings("unchecked")
	public static void tc1_verify_system_api_spec_get_request() throws ParseException, IOException {

		obj = jsonParser.parse(getCompleteData().toJSONString());
		ja = (JSONArray) obj;

		//System.out.println("Size of the data into JSON data file ==> " + ja.size());

		RestAssured.baseURI = "https://stage.api.mastercard.com/";
		RestAssured.basePath = "/de/merchantoffers/offers";

		// Going through all the data in JSON data file
		for (int i = 0; i < ja.size(); i++) {

			requestBuilder = new RequestSpecBuilder();
			respBuilder = new ResponseSpecBuilder();

			// Creating JSON object and reading each data out of JSON data file in to JSON
			// object
			JSONObject jsonObj = new JSONObject();
			jsonObj = (JSONObject) ja.get(i);

			// Storing query parameters in to mapQueryParamsObj from JSON data file
			HashMap<String, Object> mapQueryParamsObj = new HashMap<String, Object>();
			mapQueryParamsObj = (HashMap<String, Object>) jsonObj.get("queryParams");

			// Storing header parameters in to mapHeaderParamsObj from JSON data file
			HashMap<String, Object> mapHeaderParamsObj = new HashMap<String, Object>();
			mapHeaderParamsObj = (HashMap<String, Object>) jsonObj.get("headerParams");

			// Adding query parameters to request builder
			for (Entry<String, Object> e : mapQueryParamsObj.entrySet()) {
				requestBuilder.addQueryParam(e.getKey(), e.getValue());
			}

			// Adding header parameters to request builder
			for (Entry<String, Object> e : mapHeaderParamsObj.entrySet()) {
				requestBuilder.addHeader(e.getKey().toString(), e.getValue().toString());
			}

			// Building request and response specification
			requestSpec = requestBuilder.build();
			respSpecification = respBuilder.build();

			// Reading actual output of the response in to actualValue
			String actualValue = RestAssured.given().relaxedHTTPSValidation().spec(requestSpec).get().asString();

			// Reading validity's flag from JSON data file
			boolean requestValidity = (boolean) jsonObj.get("valid");
			
			// Building response builder based on validity flag (requestValidity) in data
			// file
			if (requestValidity) {//

				// When it is a valid request i.e. true in JSON data file
				/*
				 * respBuilder.expectStatusCode(200); JSONAssert.assertEquals(expectedValue,
				 * actualValue, JSONCompareMode.LENIENT);
				 * respBuilder.expectBody("location_suggestions.size()", equalTo(1));
				 * respBuilder.expectBody("location_suggestions[0]", hasKey("city_name"));
				 * respBuilder.expectBody("location_suggestions[0]", hasKey("city_id"));
				 * respBuilder.expectBody("location_suggestions[0]", hasEntry("city_name",
				 * "Hamilton")); respBuilder.expectBody("location_suggestions[0]",
				 * hasEntry("country_name", "New Zealand"));
				 * respBuilder.expectBody(containsString("status"));
				 */

			} else {

				// When it is a invalid request i.e. false in JSON data file
				/*
				 * if (i == ja.size() - 3 || i == ja.size() - 1)
				 * respBuilder.expectStatusCode(403);
				 */

			}

			// Hitting the request for given request specifications in data file and
			// verifying the response based on response specification
			// Logging URI on console
			RestAssured.given().relaxedHTTPSValidation().spec(requestSpec).log().uri().get().then()
					.spec(respSpecification);

			System.out.println(actualValue);

		}
		
		

	}
	
	@SuppressWarnings("unchecked")
	public static void tc2_verify_zomato_restaurants_review() throws ParseException, IOException {

		//obj = jsonParser.parse(getCompleteData().toJSONString());
		Reader rder = new FileReader(new File(System.getProperty("user.dir")+"/test-data/zomato_testdata.json"));
		obj = jsonParser.parse(rder);
		ja = (JSONArray) obj;

		//System.out.println("Size of the data into JSON data file ==> " + ja.size());

		RestAssured.baseURI = "https://developers.zomato.com/api/v2.1/";
		RestAssured.basePath = "/reviews";

		// Going through all the data in JSON data file
		for (int i = 0; i < ja.size(); i++) {

			requestBuilder = new RequestSpecBuilder();
			respBuilder = new ResponseSpecBuilder();

			// Creating JSON object and reading each data out of JSON data file in to JSON
			// object
			JSONObject jsonObj = new JSONObject();
			jsonObj = (JSONObject) ja.get(i);

			// Storing query parameters in to mapQueryParamsObj from JSON data file
			HashMap<String, Object> mapQueryParamsObj = new HashMap<String, Object>();
			mapQueryParamsObj = (HashMap<String, Object>) jsonObj.get("queryParams");

			// Storing header parameters in to mapHeaderParamsObj from JSON data file
			HashMap<String, Object> mapHeaderParamsObj = new HashMap<String, Object>();
			mapHeaderParamsObj = (HashMap<String, Object>) jsonObj.get("headerParams");

			// Adding query parameters to request builder
			for (Entry<String, Object> e : mapQueryParamsObj.entrySet()) {
				requestBuilder.addQueryParam(e.getKey(), e.getValue());
			}

			// Adding header parameters to request builder
			for (Entry<String, Object> e : mapHeaderParamsObj.entrySet()) {
				requestBuilder.addHeader(e.getKey().toString(), e.getValue().toString());
			}

			// Building request and response specification
			requestSpec = requestBuilder.build();
			respSpecification = respBuilder.build();

			// Reading actual output of the response in to actualValue
			String actualValue = RestAssured.given().relaxedHTTPSValidation().spec(requestSpec).get().asString();

			// Reading validity's flag from JSON data file
			boolean requestValidity = (boolean) jsonObj.get("valid");
			
			// Building response builder based on validity flag (requestValidity) in data
			// file
			if (requestValidity) {

			} else {

			}

			// Hitting the request for given request specifications in data file and
			// verifying the response based on response specification
			// Logging URI on console
			RestAssured.given().relaxedHTTPSValidation().spec(requestSpec).log().uri().get().then()
					.spec(respSpecification);

			System.out.println(actualValue);

		}
		
		

	}

}

