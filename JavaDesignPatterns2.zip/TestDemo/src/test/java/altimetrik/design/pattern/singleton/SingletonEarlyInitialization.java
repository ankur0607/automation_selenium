package altimetrik.design.pattern.singleton;

public class SingletonEarlyInitialization {

	   //create an object of SingleObject
	   private static SingletonEarlyInitialization instance = new SingletonEarlyInitialization();//Early, instance will be created at load time
	   
	   //make the constructor private so that this class cannot be
	   //instantiated
	   private SingletonEarlyInitialization(){}

	   //Get the only object available
	   public static SingletonEarlyInitialization getInstance(){
	      return instance;
	   }
	   
	   public void showMessage(){
	      System.out.println("Hello World! - in Early initialization");
	   }
	}
