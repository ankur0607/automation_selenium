package altimetrik.design.pattern.singleton;

public class SingletonLazyInitialization {
	
	private static SingletonLazyInitialization obj;
	
	//make the constructor private so that this class cannot be
	   //instantiated
	   private SingletonLazyInitialization(){}
	   
	 //Lazy instantiation
	   public static SingletonLazyInitialization getInstanceByLazy() {
		   
		   if (obj == null){  
			      synchronized(SingletonLazyInitialization.class){  
			        if (obj == null){  
			            obj = new SingletonLazyInitialization();//instance will be created at request time  
			        }  
			    }
		   }
		   return obj;
		   
	   }

	   public void showMessage(){
	      System.out.println("Hello World! - in Lazy initialization");
	   }


}
