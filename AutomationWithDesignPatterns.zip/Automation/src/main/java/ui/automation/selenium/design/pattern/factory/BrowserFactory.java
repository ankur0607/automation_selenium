package ui.automation.selenium.design.pattern.factory;

import java.io.FileReader;

import org.openqa.selenium.WebDriver;

import ui.automation.enums.DriverType;
import ui.automation.managers.FileReaderManager;

public class BrowserFactory {
	private WebDriver browserInstance = null;

	public BrowserFactory() {

	}

	/*
	 * public WebDriver getBrowser(String browserType) {
	 * 
	 * if(browserType.equalsIgnoreCase("CHROME")) browserInstance = new
	 * ChromeBrowser().getBrowser(); else
	 * if(browserType.equalsIgnoreCase("FIREFOX")) browserInstance = new
	 * FirefoxBrowser().getBrowser(); else if(browserType.equalsIgnoreCase("IE"))
	 * browserInstance = new InternetExplorerBrowser().getBrowser();
	 * 
	 * BrowserUtils.maximize(browserInstance); BrowserUtils.setImplicitTime(20,
	 * browserInstance);
	 * 
	 * return browserInstance;
	 * 
	 * }
	 */

	public WebDriver getBrowser() {

		DriverType bType = FileReaderManager.getInstance().getConfigReader().getBrowser();
		
		switch (bType) {

		case CHROME:
			browserInstance = new ChromeBrowser().getBrowser();
			break;
		case FIREFOX:
			browserInstance = new FirefoxBrowser().getBrowser();
			break;

		}

		BrowserUtils.maximize(browserInstance);
		BrowserUtils.setImplicitTime(20, browserInstance);

		return browserInstance;

	}

}
