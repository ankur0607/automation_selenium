package ui.automation.selenium.design.pattern.factory;

import org.openqa.selenium.WebDriver;

import ui.automation.managers.FileReaderManager;

public class FactoryDemo {
	static WebDriver browser;
	public static void main (String []args) {
		
		browser = new BrowserFactory().getBrowser();
		browser.get(FileReaderManager.getInstance().getConfigReader().getApplicationUrl());
				
	}

}
