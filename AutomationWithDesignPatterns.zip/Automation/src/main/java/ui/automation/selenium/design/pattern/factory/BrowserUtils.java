package ui.automation.selenium.design.pattern.factory;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;

public class BrowserUtils {
	
	public static void maximize(WebDriver driver) {
		driver.manage().window().maximize();
	}
	
	public static void setImplicitTime(long timeOut, WebDriver driver) {
		driver.manage().timeouts().implicitlyWait(timeOut, TimeUnit.SECONDS);
	}
}
