package ui.automation.selenium.design.pattern.factory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class InternetExplorerBrowser implements Browser{
	private static final String IE_DRIVER_PROPERTY = "webdriver.ie.driver";
	public WebDriver getBrowser() {
		
		System.out.println("inside @InternetExplorerBrowser");
		System.setProperty(IE_DRIVER_PROPERTY, System.getProperty("user.dir")+"/browser_exe/chromedriver.exe");
		return new InternetExplorerDriver();
		
	}

}
