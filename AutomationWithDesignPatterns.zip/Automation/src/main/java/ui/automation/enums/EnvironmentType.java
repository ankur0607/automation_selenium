package ui.automation.enums;

public enum EnvironmentType {
	
	LOCAL,
	REMOTE,
	CLOUD

}
